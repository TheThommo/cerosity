import { useState } from "react";
import { Link2, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { generateReferralUrl, copyToClipboard } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Coach, ReferralLink } from "@shared/schema";

interface LinkGeneratorProps {
  coach: Coach;
}

export default function LinkGenerator({ coach }: LinkGeneratorProps) {
  const [campaignName, setCampaignName] = useState("");
  const [courseId, setCourseId] = useState("");
  const [utmParams, setUtmParams] = useState("");
  const [generatedLink, setGeneratedLink] = useState("");
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  const generateLinkMutation = useMutation({
    mutationFn: async (linkData: any) => {
      const response = await apiRequest("POST", "/api/referral-links", linkData);
      return response.json();
    },
    onSuccess: (newLink: ReferralLink) => {
      const url = generateReferralUrl(coach.coachId, newLink.linkId);
      setGeneratedLink(url);
      queryClient.invalidateQueries({ queryKey: ["/api/referral-links"] });
      toast({
        title: "Referral link generated",
        description: "Your personalized referral link is ready to share.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate referral link. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateLink = () => {
    if (!campaignName.trim()) {
      toast({
        title: "Campaign name required",
        description: "Please enter a campaign name for your referral link.",
        variant: "destructive",
      });
      return;
    }

    generateLinkMutation.mutate({
      coachId: coach.id,
      campaignName,
      courseId: courseId || null,
      utmParams: utmParams || null,
    });
  };

  const handleCopyLink = async () => {
    if (!generatedLink) return;
    
    const success = await copyToClipboard(generatedLink);
    if (success) {
      setCopied(true);
      toast({
        title: "Link copied",
        description: "Referral link copied to clipboard.",
      });
      setTimeout(() => setCopied(false), 2000);
    } else {
      toast({
        title: "Copy failed",
        description: "Failed to copy link. Please copy manually.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-6">Generate Your Referral Link</h3>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div>
              <Label htmlFor="campaignName">Campaign Name</Label>
              <Input
                id="campaignName"
                placeholder="e.g., Winter Golf Program 2024"
                value={campaignName}
                onChange={(e) => setCampaignName(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="courseId">Course/Package</Label>
              <Select value={courseId} onValueChange={setCourseId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a course..." />
                </SelectTrigger>
                <SelectContent>
                  {courses.map((course: any) => (
                    <SelectItem key={course.id} value={course.id}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="utmParams">Custom UTM Parameters (Optional)</Label>
              <Input
                id="utmParams"
                placeholder="utm_medium=social&utm_campaign=winter2024"
                value={utmParams}
                onChange={(e) => setUtmParams(e.target.value)}
              />
            </div>
            <Button
              onClick={handleGenerateLink}
              disabled={generateLinkMutation.isPending}
              className="w-full"
            >
              <Link2 className="w-4 h-4 mr-2" />
              {generateLinkMutation.isPending ? "Generating..." : "Generate Referral Link"}
            </Button>
          </div>
          <div>
            <div className="bg-gray-50 rounded-lg p-6">
              <h4 className="font-semibold mb-4">Generated Link</h4>
              <div className="bg-white border border-gray-200 rounded-lg p-4 mb-4">
                <p className="text-sm text-neutral mb-2">Your personalized referral link:</p>
                <div className="flex items-center space-x-2">
                  <Input
                    readOnly
                    value={generatedLink || "Generate a link first..."}
                    className="flex-1 text-sm bg-gray-50 border-0"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyLink}
                    disabled={!generatedLink}
                  >
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral">Coach ID:</span>
                  <span className="font-medium">{coach.coachId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral">Discount Applied:</span>
                  <span className="font-medium text-success">10% automatic</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral">Commission Rate:</span>
                  <span className="font-medium">15% per referral</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
