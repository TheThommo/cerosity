import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Home, ArrowLeft, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth, useLogout } from "@/hooks/useAuth";

interface NavigationHeaderProps {
  title: string;
  breadcrumbs?: Array<{ label: string; path?: string }>;
  showBack?: boolean;
  backPath?: string;
  customActions?: React.ReactNode;
}

export default function NavigationHeader({ 
  title, 
  breadcrumbs = [], 
  showBack = false, 
  backPath,
  customActions 
}: NavigationHeaderProps) {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const logoutMutation = useLogout();

  const handleBack = () => {
    if (backPath) {
      setLocation(backPath);
    } else {
      window.history.back();
    }
  };

  const handleHome = () => {
    if (user?.role === 'admin') {
      setLocation("/admin-dashboard");
    } else if (user?.role === 'coach') {
      setLocation("/coach-dashboard");
    } else if (user?.role === 'student') {
      setLocation("/student-dashboard");
    } else {
      setLocation("/");
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="bg-white border-b border-gray-200 px-4 sm:px-6 lg:px-8 py-4">
      <div className="max-w-7xl mx-auto">
        {/* Top row with user info and logout */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center space-x-3">
            {user && (
              <>
                <span className="text-sm text-gray-600">Welcome back,</span>
                <span className="font-medium text-gray-900">{user.name}</span>
                <Badge variant={
                  user.role === 'admin' ? 'default' : 
                  user.role === 'coach' ? 'secondary' : 
                  'outline'
                }>
                  {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                </Badge>
              </>
            )}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="h-4 w-4 mr-1" />
            Logout
          </Button>
        </div>

        {/* Breadcrumb navigation */}
        {breadcrumbs.length > 0 && (
          <nav className="flex mb-3" aria-label="Breadcrumb">
            <ol className="flex items-center space-x-2 text-sm">
              {breadcrumbs.map((crumb, index) => (
                <li key={index} className="flex items-center">
                  {index > 0 && <span className="mx-2 text-gray-400">/</span>}
                  {crumb.path ? (
                    <button
                      onClick={() => setLocation(crumb.path!)}
                      className="text-blue-600 hover:text-blue-800 hover:underline"
                    >
                      {crumb.label}
                    </button>
                  ) : (
                    <span className="text-gray-500">{crumb.label}</span>
                  )}
                </li>
              ))}
            </ol>
          </nav>
        )}

        {/* Main navigation row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            {showBack && (
              <Button variant="outline" size="sm" onClick={handleBack}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            )}

            <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
          </div>

          {customActions && (
            <div className="flex items-center space-x-2">
              {customActions}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}