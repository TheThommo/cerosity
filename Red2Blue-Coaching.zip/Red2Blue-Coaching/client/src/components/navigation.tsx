import { Bell, Club } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Link } from "wouter";

interface NavigationProps {
  coach?: {
    id: number;
    name: string;
    coachId: string;
  };
}

export default function Navigation({ coach }: NavigationProps) {
  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-2">
              <Club className="text-primary text-2xl" />
              <span className="text-xl font-bold text-primary">Red2Blue Coaching</span>
            </Link>
            <span className="text-sm text-neutral hidden sm:block">Affiliate Referral Platform</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5 text-neutral" />
              <span className="absolute -top-1 -right-1 bg-secondary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                3
              </span>
            </Button>
            {coach && (
              <div className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${coach.name}`} />
                  <AvatarFallback>{coach.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <div className="hidden sm:block">
                  <div className="text-sm font-medium">{coach.name}</div>
                  <div className="text-xs text-neutral">{coach.coachId}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
