import { Eye } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Referral } from "@shared/schema";

interface ReferralsTableProps {
  referrals: Referral[];
  onViewDetails?: (referral: Referral) => void;
}

export default function ReferralsTable({ referrals, onViewDetails }: ReferralsTableProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-success/10 text-success";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Student</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Referral Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Commission</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {referrals.map((referral) => (
            <TableRow key={referral.id} className="hover:bg-gray-50">
              <TableCell>
                <div className="flex items-center space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${referral.studentName}`} />
                    <AvatarFallback>
                      {referral.studentName.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{referral.studentName}</span>
                </div>
              </TableCell>
              <TableCell className="text-sm text-neutral">{referral.studentEmail}</TableCell>
              <TableCell className="text-sm text-neutral">
                {formatDate(referral.createdAt!)}
              </TableCell>
              <TableCell>
                <Badge className={getStatusColor(referral.status)} variant="secondary">
                  {referral.status.charAt(0).toUpperCase() + referral.status.slice(1)}
                </Badge>
              </TableCell>
              <TableCell className="text-sm font-medium">
                {formatCurrency(referral.commissionAmount)}
              </TableCell>
              <TableCell>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onViewDetails?.(referral)}
                >
                  <Eye className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
