import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeLabel?: string;
  icon: LucideIcon;
  iconColor: string;
  iconBgColor: string;
}

export default function StatsCard({
  title,
  value,
  change,
  changeLabel,
  icon: Icon,
  iconColor,
  iconBgColor,
}: StatsCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-neutral font-medium">{title}</p>
            <p className="text-2xl font-bold text-foreground">{value}</p>
          </div>
          <div className={`${iconBgColor} p-3 rounded-lg`}>
            <Icon className={`${iconColor} text-xl w-5 h-5`} />
          </div>
        </div>
        {change && changeLabel && (
          <div className="flex items-center mt-4 text-sm">
            <span className="text-success font-medium">{change}</span>
            <span className="text-neutral ml-1">{changeLabel}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
