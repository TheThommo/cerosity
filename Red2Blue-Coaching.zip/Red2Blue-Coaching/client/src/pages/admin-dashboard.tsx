import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Calendar, Users, GraduationCap, DollarSign, TrendingUp, Eye, CheckCircle, XCircle, Clock, BookOpen } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/navigation";
import StatsCard from "@/components/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Admin, Coach, Student, Enrollment, Session } from "@shared/schema";

interface AdminStats {
  totalCoaches: number;
  totalStudents: number;
  totalEnrollments: number;
  completedCourses: number;
  totalRevenue: number;
}

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const { toast } = useToast();
  const isAdmin = user?.role === 'admin';

  const { data: stats } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    enabled: isAuthenticated && isAdmin,
  });

  const { data: coaches = [] } = useQuery<Coach[]>({
    queryKey: ["/api/coaches"],
    enabled: isAuthenticated && isAdmin,
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
    enabled: isAuthenticated && isAdmin,
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
    enabled: isAuthenticated && isAdmin,
  });

  const { data: sessions = [] } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
    enabled: isAuthenticated && isAdmin,
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-neutral">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-6 text-center">
            <h1 className="text-xl font-bold text-destructive mb-2">Access Denied</h1>
            <p className="text-neutral">You need admin privileges to access this dashboard.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
      case "active":
      case "completed":
        return "bg-success/10 text-success";
      case "pending":
      case "scheduled":
        return "bg-yellow-100 text-yellow-800";
      case "rejected":
      case "cancelled":
      case "missed":
        return "bg-red-100 text-red-800";
      case "in_progress":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const todaysSessions = sessions.filter(session => {
    if (!selectedDate || !session.scheduledDate) return false;
    const sessionDate = new Date(session.scheduledDate);
    return sessionDate.toDateString() === selectedDate.toDateString();
  });

  const upcomingSessions = sessions.filter(session => {
    if (!session.scheduledDate) return false;
    const sessionDate = new Date(session.scheduledDate);
    const today = new Date();
    return sessionDate > today && sessionDate <= new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
  }).slice(0, 10);

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-neutral mt-2">Complete oversight of coaches, students, and course attendance</p>
        </div>

        {/* Stats Overview */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
            <StatsCard
              title="Total Coaches"
              value={stats.totalCoaches}
              change={`${coaches.filter(c => c.status === 'approved').length} active`}
              changeLabel="approved coaches"
              icon={Users}
              iconColor="text-primary"
              iconBgColor="bg-primary/10"
            />
            <StatsCard
              title="Total Students"
              value={stats.totalStudents}
              change={`${students.filter(s => s.status === 'active').length} active`}
              changeLabel="enrolled students"
              icon={GraduationCap}
              iconColor="text-success"
              iconBgColor="bg-success/10"
            />
            <StatsCard
              title="Course Enrollments"
              value={stats.totalEnrollments}
              change={`${enrollments.filter(e => e.status === 'in_progress').length} active`}
              changeLabel="in progress"
              icon={BookOpen}
              iconColor="text-blue-600"
              iconBgColor="bg-blue-100"
            />
            <StatsCard
              title="Completed Courses"
              value={stats.completedCourses}
              icon={CheckCircle}
              iconColor="text-success"
              iconBgColor="bg-success/10"
            />
            <StatsCard
              title="Total Revenue"
              value={formatCurrency(stats.totalRevenue)}
              icon={DollarSign}
              iconColor="text-secondary"
              iconBgColor="bg-secondary/10"
            />
          </div>
        )}

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calendar and Sessions */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5" />
                  <span>Session Calendar</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CalendarComponent
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                />
                
                {selectedDate && (
                  <div className="mt-6">
                    <h4 className="font-semibold mb-3">
                      Sessions on {formatDate(selectedDate)}
                    </h4>
                    {todaysSessions.length > 0 ? (
                      <div className="space-y-2">
                        {todaysSessions.map((session) => (
                          <div key={session.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div className="text-sm">
                              <div className="font-medium">Session #{session.sessionNumber}</div>
                              <div className="text-neutral">
                                {new Date(session.scheduledDate).toLocaleTimeString()}
                              </div>
                            </div>
                            <Badge className={getStatusColor(session.status)} variant="secondary">
                              {session.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-neutral">No sessions scheduled</p>
                    )}
                  </div>
                )}

                <div className="mt-6">
                  <h4 className="font-semibold mb-3">Upcoming Sessions</h4>
                  {upcomingSessions.length > 0 ? (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {upcomingSessions.map((session) => (
                        <div key={session.id} className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm">
                          <div>
                            <div className="font-medium">Session #{session.sessionNumber}</div>
                            <div className="text-neutral">
                              {formatDate(session.scheduledDate)}
                            </div>
                          </div>
                          <Badge className={getStatusColor(session.status)} variant="secondary">
                            {session.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-neutral">No upcoming sessions</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Management Tables */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="coaches" className="space-y-6">
              <Card>
                <div className="border-b border-gray-200">
                  <TabsList className="h-auto p-0 bg-transparent">
                    <TabsTrigger
                      value="coaches"
                      className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    >
                      Coaches ({coaches.length})
                    </TabsTrigger>
                    <TabsTrigger
                      value="students"
                      className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    >
                      Students ({students.length})
                    </TabsTrigger>
                    <TabsTrigger
                      value="enrollments"
                      className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    >
                      Enrollments ({enrollments.length})
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="coaches">
                  <CardContent className="p-6">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Coach</TableHead>
                            <TableHead>Coach ID</TableHead>
                            <TableHead>Certification</TableHead>
                            <TableHead>Students</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {coaches.map((coach) => {
                            const coachStudents = students.filter(s => s.coachId === coach.id);
                            return (
                              <TableRow key={coach.id}>
                                <TableCell>
                                  <div className="flex items-center space-x-3">
                                    <Avatar className="w-8 h-8">
                                      <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${coach.name}`} />
                                      <AvatarFallback>
                                        {coach.name.split(' ').map(n => n[0]).join('')}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="font-medium">{coach.name}</div>
                                      <div className="text-sm text-neutral">{coach.email}</div>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell className="font-mono text-sm">{coach.coachId}</TableCell>
                                <TableCell>{coach.certification}</TableCell>
                                <TableCell>{coachStudents.length}</TableCell>
                                <TableCell>
                                  <Badge className={getStatusColor(coach.status)} variant="secondary">
                                    {coach.status}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="flex space-x-2">
                                    <Button size="sm" variant="ghost">
                                      <Eye className="w-4 h-4" />
                                    </Button>
                                    {coach.status === "pending" && (
                                      <>
                                        <Button size="sm" variant="outline">
                                          <CheckCircle className="w-4 h-4" />
                                        </Button>
                                        <Button size="sm" variant="outline">
                                          <XCircle className="w-4 h-4" />
                                        </Button>
                                      </>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </TabsContent>

                <TabsContent value="students">
                  <CardContent className="p-6">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student</TableHead>
                            <TableHead>Student ID</TableHead>
                            <TableHead>Coach</TableHead>
                            <TableHead>Enrollments</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {students.map((student) => {
                            const coach = coaches.find(c => c.id === student.coachId);
                            const studentEnrollments = enrollments.filter(e => e.studentId === student.id);
                            return (
                              <TableRow key={student.id}>
                                <TableCell>
                                  <div className="flex items-center space-x-3">
                                    <Avatar className="w-8 h-8">
                                      <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${student.name}`} />
                                      <AvatarFallback>
                                        {student.name.split(' ').map(n => n[0]).join('')}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="font-medium">{student.name}</div>
                                      <div className="text-sm text-neutral">{student.email}</div>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell className="font-mono text-sm">{student.studentId}</TableCell>
                                <TableCell>
                                  {coach ? (
                                    <div className="text-sm">
                                      <div className="font-medium">{coach.name}</div>
                                      <div className="text-neutral">{coach.coachId}</div>
                                    </div>
                                  ) : (
                                    <span className="text-neutral">Unassigned</span>
                                  )}
                                </TableCell>
                                <TableCell>{studentEnrollments.length}</TableCell>
                                <TableCell>
                                  <Badge className={getStatusColor(student.status)} variant="secondary">
                                    {student.status}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <Button size="sm" variant="ghost">
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </TabsContent>

                <TabsContent value="enrollments">
                  <CardContent className="p-6">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student</TableHead>
                            <TableHead>Course</TableHead>
                            <TableHead>Coach</TableHead>
                            <TableHead>Progress</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Start Date</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {enrollments.map((enrollment) => {
                            const student = students.find(s => s.id === enrollment.studentId);
                            const coach = coaches.find(c => c.id === enrollment.coachId);
                            return (
                              <TableRow key={enrollment.id}>
                                <TableCell>
                                  <div className="text-sm">
                                    <div className="font-medium">{student?.name}</div>
                                    <div className="text-neutral">{student?.studentId}</div>
                                  </div>
                                </TableCell>
                                <TableCell className="text-sm">Course #{enrollment.courseId}</TableCell>
                                <TableCell>
                                  <div className="text-sm">
                                    <div className="font-medium">{coach?.name}</div>
                                    <div className="text-neutral">{coach?.coachId}</div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <div className="w-16 bg-gray-200 rounded-full h-2">
                                      <div 
                                        className="bg-primary h-2 rounded-full" 
                                        style={{ width: `${enrollment.progress || 0}%` }}
                                      />
                                    </div>
                                    <span className="text-sm">{enrollment.progress || 0}%</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge className={getStatusColor(enrollment.status)} variant="secondary">
                                    {enrollment.status}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-sm">
                                  {formatDate(enrollment.startDate)}
                                </TableCell>
                                <TableCell>
                                  <Button size="sm" variant="ghost">
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </TabsContent>
              </Card>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}