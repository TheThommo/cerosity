import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users, DollarSign, TrendingUp, Eye, CheckCircle, XCircle } from "lucide-react";
import Navigation from "@/components/navigation";
import StatsCard from "@/components/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Coach, Referral, Payout } from "@shared/schema";

export default function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: coaches = [] } = useQuery<Coach[]>({
    queryKey: ["/api/coaches"],
  });

  const { data: referrals = [] } = useQuery<Referral[]>({
    queryKey: ["/api/referrals"],
  });

  const { data: payouts = [] } = useQuery<Payout[]>({
    queryKey: ["/api/payouts"],
  });

  const updateCoachStatusMutation = useMutation({
    mutationFn: async ({ coachId, status }: { coachId: number; status: string }) => {
      const response = await apiRequest("PATCH", `/api/coaches/${coachId}/status`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/coaches"] });
      toast({
        title: "Coach status updated",
        description: "The coach status has been successfully updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update coach status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createPayoutMutation = useMutation({
    mutationFn: async ({ coachId, amount }: { coachId: number; amount: number }) => {
      const response = await apiRequest("POST", "/api/payouts", { coachId, amount });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payouts"] });
      toast({
        title: "Payout created",
        description: "The payout has been successfully created.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create payout. Please try again.",
        variant: "destructive",
      });
    },
  });

  const totalCommissions = referrals.reduce((sum, ref) => sum + parseFloat(ref.commissionAmount), 0);
  const pendingPayouts = payouts.filter(p => p.status === "pending").reduce((sum, p) => sum + parseFloat(p.amount), 0);
  const activeCoaches = coaches.filter(c => c.status === "approved").length;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
      case "active":
      case "processed":
        return "bg-success/10 text-success";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "rejected":
      case "failed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-neutral mt-2">Manage coaches, referrals, and payouts</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Coaches"
            value={coaches.length}
            change={`${activeCoaches} active`}
            changeLabel="approved coaches"
            icon={Users}
            iconColor="text-primary"
            iconBgColor="bg-primary/10"
          />
          <StatsCard
            title="Total Referrals"
            value={referrals.length}
            icon={TrendingUp}
            iconColor="text-success"
            iconBgColor="bg-success/10"
          />
          <StatsCard
            title="Total Commissions"
            value={formatCurrency(totalCommissions)}
            icon={DollarSign}
            iconColor="text-secondary"
            iconBgColor="bg-secondary/10"
          />
          <StatsCard
            title="Pending Payouts"
            value={formatCurrency(pendingPayouts)}
            icon={DollarSign}
            iconColor="text-yellow-600"
            iconBgColor="bg-yellow-100"
          />
        </div>

        {/* Tabbed Interface */}
        <Tabs defaultValue="coaches" className="space-y-6">
          <Card>
            <div className="border-b border-gray-200">
              <TabsList className="h-auto p-0 bg-transparent">
                <TabsTrigger
                  value="coaches"
                  className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                >
                  Coaches
                </TabsTrigger>
                <TabsTrigger
                  value="referrals"
                  className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                >
                  Referrals
                </TabsTrigger>
                <TabsTrigger
                  value="payouts"
                  className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                >
                  Payouts
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="coaches">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold">Coach Management</h3>
                </div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Coach</TableHead>
                        <TableHead>Coach ID</TableHead>
                        <TableHead>Certification</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {coaches.map((coach) => (
                        <TableRow key={coach.id}>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${coach.name}`} />
                                <AvatarFallback>
                                  {coach.name.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{coach.name}</div>
                                <div className="text-sm text-neutral">{coach.email}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{coach.coachId}</TableCell>
                          <TableCell>{coach.certification}</TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(coach.status)} variant="secondary">
                              {coach.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-neutral">
                            {formatDate(coach.createdAt!)}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              {coach.status === "pending" && (
                                <>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => updateCoachStatusMutation.mutate({ coachId: coach.id, status: "approved" })}
                                  >
                                    <CheckCircle className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => updateCoachStatusMutation.mutate({ coachId: coach.id, status: "rejected" })}
                                  >
                                    <XCircle className="w-4 h-4" />
                                  </Button>
                                </>
                              )}
                              <Button size="sm" variant="ghost">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </TabsContent>

            <TabsContent value="referrals">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold">All Referrals</h3>
                </div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Coach</TableHead>
                        <TableHead>Course</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Commission</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {referrals.map((referral) => {
                        const coach = coaches.find(c => c.id === referral.coachId);
                        return (
                          <TableRow key={referral.id}>
                            <TableCell>
                              <div>
                                <div className="font-medium">{referral.studentName}</div>
                                <div className="text-sm text-neutral">{referral.studentEmail}</div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="text-sm">
                                <div className="font-medium">{coach?.name}</div>
                                <div className="text-neutral">{coach?.coachId}</div>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm">{referral.courseSelected}</TableCell>
                            <TableCell>
                              <Badge className={getStatusColor(referral.status)} variant="secondary">
                                {referral.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium">
                              {formatCurrency(referral.commissionAmount)}
                            </TableCell>
                            <TableCell className="text-sm text-neutral">
                              {formatDate(referral.createdAt!)}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </TabsContent>

            <TabsContent value="payouts">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold">Payout Management</h3>
                </div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Coach</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Processed</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {payouts.map((payout) => {
                        const coach = coaches.find(c => c.id === payout.coachId);
                        return (
                          <TableRow key={payout.id}>
                            <TableCell>
                              <div className="text-sm">
                                <div className="font-medium">{coach?.name}</div>
                                <div className="text-neutral">{coach?.coachId}</div>
                              </div>
                            </TableCell>
                            <TableCell className="font-medium">
                              {formatCurrency(payout.amount)}
                            </TableCell>
                            <TableCell>
                              <Badge className={getStatusColor(payout.status)} variant="secondary">
                                {payout.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm text-neutral">
                              {formatDate(payout.createdAt!)}
                            </TableCell>
                            <TableCell className="text-sm text-neutral">
                              {payout.processedAt ? formatDate(payout.processedAt) : '-'}
                            </TableCell>
                            <TableCell>
                              <Button size="sm" variant="ghost">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </TabsContent>
          </Card>
        </Tabs>
      </div>
    </div>
  );
}
