import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users, DollarSign, TrendingUp, Calendar, CheckCircle } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/utils";
import NavigationHeader from "@/components/navigation-header";
import type { Coach, Student, Enrollment, Payout, Referral } from "@shared/schema";

interface CoachStats {
  totalReferrals: number;
  activeStudents: number;
  pendingPayout: number;
  conversionRate: number;
}

interface AttendanceRecord {
  id: number;
  studentId: number;
  date: string;
  status: 'present' | 'absent' | 'late';
  notes?: string;
  acknowledgedBy: 'student' | 'admin';
  createdAt: Date;
}

export default function CoachDashboardSimple() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");

  // Data queries
  const { data: coach } = useQuery<Coach>({
    queryKey: [`/api/coaches/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: stats } = useQuery<CoachStats>({
    queryKey: [`/api/coaches/${user?.id}/stats`],
    enabled: !!user?.id,
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  const { data: payouts = [] } = useQuery<Payout[]>({
    queryKey: [`/api/payouts/coach/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: referrals = [] } = useQuery<Referral[]>({
    queryKey: [`/api/referrals/coach/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: attendanceRecords = [] } = useQuery<AttendanceRecord[]>({
    queryKey: [`/api/attendance/coach/${user?.id}`],
    enabled: !!user?.id,
  });

  // Filter data for this coach
  const myStudents = students.filter((student: Student) => student.coachId === user?.id);
  const myEnrollments = enrollments.filter((enrollment: Enrollment) => enrollment.coachId === user?.id);

  // Calculate recent activity from attendance records
  const recentActivity = attendanceRecords
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10);

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader title="Coach Dashboard" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">My Students</CardTitle>
              <Users className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{myStudents.length}</div>
              <p className="text-xs text-muted-foreground">
                {myStudents.filter(s => s.status === 'active').length} active
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Referrals</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{referrals.length}</div>
              <p className="text-xs text-muted-foreground">
                {referrals.filter(r => r.status === 'converted').length} converted
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Payout</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(stats?.pendingPayout || 0)}</div>
              <p className="text-xs text-muted-foreground">From referrals</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">This Month</CardTitle>
              <Calendar className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {attendanceRecords.filter(a => 
                  new Date(a.date).getMonth() === new Date().getMonth() && 
                  a.status === 'present'
                ).length}
              </div>
              <p className="text-xs text-muted-foreground">Student attendances</p>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-4 mb-6">
          <Button 
            variant={activeTab === "overview" ? "default" : "outline"}
            onClick={() => setActiveTab("overview")}
          >
            Overview
          </Button>
          <Button 
            variant={activeTab === "students" ? "default" : "outline"}
            onClick={() => setActiveTab("students")}
          >
            My Students
          </Button>
          <Button 
            variant={activeTab === "payouts" ? "default" : "outline"}
            onClick={() => setActiveTab("payouts")}
          >
            Payouts
          </Button>
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Student Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((record) => {
                    const student = students.find(s => s.id === record.studentId);
                    return (
                      <div key={record.id} className="flex items-center justify-between p-3 border rounded">
                        <div>
                          <p className="font-medium">{student?.name}</p>
                          <p className="text-sm text-gray-600">
                            {formatDate(record.date)} - {record.status}
                          </p>
                          <p className="text-xs text-gray-500">
                            Acknowledged by {record.acknowledgedBy}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={
                            record.status === 'present' ? 'default' :
                            record.status === 'late' ? 'secondary' : 'destructive'
                          }>
                            {record.status}
                          </Badge>
                          {record.acknowledgedBy === 'student' && (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          )}
                        </div>
                      </div>
                    );
                  })}
                  {recentActivity.length === 0 && (
                    <p className="text-gray-500 text-center py-8">
                      No recent attendance records. Student activity will appear here once they start acknowledging their attendance.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "students" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Students & Attendance Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Student ID</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Attendance</TableHead>
                      <TableHead>This Month</TableHead>
                      <TableHead>Joined</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {myStudents.map((student) => {
                      const studentAttendance = attendanceRecords.filter(a => a.studentId === student.id);
                      const lastAttendance = studentAttendance
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
                      const thisMonthAttendance = studentAttendance.filter(a => 
                        new Date(a.date).getMonth() === new Date().getMonth() &&
                        a.status === 'present'
                      ).length;

                      return (
                        <TableRow key={student.id}>
                          <TableCell className="font-medium">{student.name}</TableCell>
                          <TableCell>{student.studentId}</TableCell>
                          <TableCell>{student.email}</TableCell>
                          <TableCell>
                            <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                              {student.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {lastAttendance ? (
                              <div>
                                <p className="text-sm">{formatDate(lastAttendance.date)}</p>
                                <Badge 
                                  variant={
                                    lastAttendance.status === 'present' ? 'default' :
                                    lastAttendance.status === 'late' ? 'secondary' : 'destructive'
                                  }
                                  className="text-xs"
                                >
                                  {lastAttendance.status}
                                </Badge>
                              </div>
                            ) : (
                              <span className="text-gray-400">No records</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <span className="font-medium">{thisMonthAttendance}</span>
                              <span className="text-xs text-gray-500">days</span>
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(student.createdAt)}</TableCell>
                        </TableRow>
                      );
                    })}
                    {myStudents.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-gray-500">
                          No students assigned yet. Share your referral links to start attracting students.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "payouts" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Payout History</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Transaction ID</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payouts.map((payout) => (
                      <TableRow key={payout.id}>
                        <TableCell>{formatDate(payout.createdAt)}</TableCell>
                        <TableCell className="font-medium">{formatCurrency(payout.amount)}</TableCell>
                        <TableCell>
                          <Badge variant={payout.status === 'paid' ? 'default' : 'secondary'}>
                            {payout.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{payout.paymentMethod || 'Bank Transfer'}</TableCell>
                        <TableCell className="font-mono text-sm">
                          {payout.transactionId || 'Pending'}
                        </TableCell>
                      </TableRow>
                    ))}
                    {payouts.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-gray-500">
                          No payouts yet. Commissions will appear here once referrals convert to paid students.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Commission Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-600">Total Earned</p>
                    <p className="text-2xl font-bold text-blue-800">
                      {formatCurrency(payouts.reduce((sum, p) => sum + parseFloat(p.amount), 0))}
                    </p>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <p className="text-sm text-green-600">Pending Payout</p>
                    <p className="text-2xl font-bold text-green-800">
                      {formatCurrency(stats?.pendingPayout || 0)}
                    </p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <p className="text-sm text-purple-600">Active Referrals</p>
                    <p className="text-2xl font-bold text-purple-800">
                      {referrals.filter(r => r.status === 'converted').length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}