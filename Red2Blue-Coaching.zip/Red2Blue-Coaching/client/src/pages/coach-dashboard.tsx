import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, GraduationCap, DollarSign, TrendingUp, Calendar, BookOpen, Share, BarChart, Download, QrCode, Copy, UserPlus } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/navigation";
import StatsCard from "@/components/stats-card";
import ReferralsTable from "@/components/referrals-table";
import LinkGenerator from "@/components/link-generator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Coach, Student, Enrollment, Session, Referral } from "@shared/schema";

interface CoachStats {
  totalReferrals: number;
  activeStudents: number;
  pendingPayout: number;
  conversionRate: number;
}

export default function CoachDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [currentView, setCurrentView] = useState<'dashboard' | 'students' | 'referrals' | 'payouts'>('dashboard');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const { toast } = useToast();
  const isCoach = user?.role === 'coach';

  const { data: coach } = useQuery<Coach>({
    queryKey: [`/api/coaches/${user?.id}`],
    enabled: isAuthenticated && isCoach && !!user?.id,
  });

  const { data: stats } = useQuery<CoachStats>({
    queryKey: [`/api/coaches/${user?.id}/stats`],
    enabled: isAuthenticated && isCoach && !!user?.id,
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
    enabled: isAuthenticated && isCoach,
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
    enabled: isAuthenticated && isCoach,
  });

  const { data: referrals = [] } = useQuery<Referral[]>({
    queryKey: [`/api/referrals/coach/${user?.id}`],
    enabled: isAuthenticated && isCoach && !!user?.id,
  });

  const { data: referralLinks = [] } = useQuery<any[]>({
    queryKey: [`/api/referral-links/coach/${user?.id}`],
    enabled: isAuthenticated && isCoach && !!user?.id,
  });

  const { data: payouts = [] } = useQuery<any[]>({
    queryKey: [`/api/payouts/coach/${user?.id}`],
    enabled: isAuthenticated && isCoach && !!user?.id,
  });

  if (!isCoach) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-6 text-center">
            <h1 className="text-xl font-bold text-destructive mb-2">Access Denied</h1>
            <p className="text-neutral">You need coach privileges to access this dashboard.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
      case "completed":
        return "bg-success/10 text-success";
      case "pending":
      case "scheduled":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
      case "missed":
        return "bg-red-100 text-red-800";
      case "in_progress":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const activeEnrollments = enrollments.filter(e => e.status === 'in_progress');
  const completedEnrollments = enrollments.filter(e => e.status === 'completed');

  // Get the default referral link for inviting students
  const defaultReferralLink = referralLinks.find(link => link.linkId.includes('default')) || referralLinks[0];
  const inviteUrl = defaultReferralLink ? `${window.location.origin}/signup?ref=${defaultReferralLink.linkId}` : null;

  const copyInviteLink = () => {
    if (inviteUrl) {
      navigator.clipboard.writeText(inviteUrl);
      toast({
        title: "Link Copied!",
        description: "Referral link copied to clipboard",
      });
    }
  };

  const generateQRCode = () => {
    if (inviteUrl) {
      // Simple QR code generation using a service
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(inviteUrl)}`;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head><title>QR Code - Invite Students</title></head>
            <body style="text-align: center; padding: 20px; font-family: Arial, sans-serif;">
              <h2>Share this QR Code with Students</h2>
              <img src="${qrUrl}" alt="QR Code" style="border: 1px solid #ccc; padding: 10px;" />
              <p style="margin-top: 20px; font-size: 12px; color: #666;">
                Students can scan this code to sign up with your referral link
              </p>
              <p style="font-size: 10px; color: #999; margin-top: 20px;">
                ${inviteUrl}
              </p>
            </body>
          </html>
        `);
      }
    }
  };

  // Render different views based on currentView state
  if (currentView === 'students') {
    return (
      <div className="min-h-screen bg-[#F8F9FA]">
        <Navigation coach={coach} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">My Students</h1>
              <p className="text-gray-600">Manage and track your students' progress</p>
            </div>
            <Button onClick={() => setCurrentView('dashboard')} variant="outline">
              Back to Dashboard
            </Button>
          </div>
          <div className="grid gap-6">
            {students.map((student: any) => (
              <Card key={student.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold">{student.name}</h3>
                      <p className="text-gray-600">ID: {student.studentId}</p>
                      <p className="text-gray-600">{student.email}</p>
                    </div>
                    <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                      {student.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (currentView === 'referrals') {
    return (
      <div className="min-h-screen bg-[#F8F9FA]">
        <Navigation coach={coach} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Referrals</h1>
              <p className="text-gray-600">Track your referral performance</p>
            </div>
            <Button onClick={() => setCurrentView('dashboard')} variant="outline">
              Back to Dashboard
            </Button>
          </div>
          <div className="grid gap-6">
            {referrals.map((referral: any) => (
              <Card key={referral.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold">{referral.studentName}</h3>
                      <p className="text-gray-600">Status: {referral.status}</p>
                      <p className="text-gray-600">Signup Date: {formatDate(referral.signupDate)}</p>
                    </div>
                    <Badge variant={referral.status === 'converted' ? 'default' : 'secondary'}>
                      {referral.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (currentView === 'payouts') {
    return (
      <div className="min-h-screen bg-[#F8F9FA]">
        <Navigation coach={coach} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Payouts</h1>
              <p className="text-gray-600">View your commission history and pending payouts</p>
            </div>
            <Button onClick={() => setCurrentView('dashboard')} variant="outline">
              Back to Dashboard
            </Button>
          </div>
          <div className="grid gap-6">
            {payouts.map((payout: any) => (
              <Card key={payout.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold">{formatCurrency(payout.amount)}</h3>
                      <p className="text-gray-600">Date: {formatDate(payout.createdAt)}</p>
                      <p className="text-gray-600">Status: {payout.status}</p>
                    </div>
                    <Badge variant={payout.status === 'paid' ? 'default' : 'secondary'}>
                      {payout.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <Navigation coach={coach} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary to-blue-600 rounded-xl p-8 mb-8 text-white">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-3xl font-bold mb-4">Welcome Back, {coach?.name}</h1>
              <p className="text-blue-100 mb-6">
                Manage your students, track their progress, and grow your coaching business with our integrated platform.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button 
                  variant="secondary" 
                  className="bg-white text-primary hover:bg-gray-50"
                  onClick={() => setCurrentView('students')}
                >
                  <Users className="w-4 h-4 mr-2" />
                  View Students
                </Button>
                <Button 
                  variant="outline" 
                  className="border-white text-white hover:bg-white hover:text-primary"
                  onClick={() => setShowInviteModal(true)}
                  disabled={!inviteUrl}
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Invite Student
                </Button>
              </div>
            </div>
            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1535131749006-b7f58c99034b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
                alt="Golf course landscape"
                className="rounded-lg shadow-lg mx-auto"
              />
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div onClick={() => setCurrentView('students')} className="cursor-pointer">
              <StatsCard
                title="My Students"
                value={students.length}
                change={`${activeEnrollments.length} active`}
                changeLabel="enrollments"
                icon={Users}
                iconColor="text-primary"
                iconBgColor="bg-primary/10"
              />
            </div>
            <div onClick={() => setCurrentView('students')} className="cursor-pointer">
              <StatsCard
                title="Course Completions"
                value={completedEnrollments.length}
                icon={GraduationCap}
                iconColor="text-success"
                iconBgColor="bg-success/10"
              />
            </div>
            <div onClick={() => setCurrentView('payouts')} className="cursor-pointer">
              <StatsCard
                title="Pending Payout"
                value={formatCurrency(stats.pendingPayout)}
                changeLabel="Next payout: Dec 15"
                icon={DollarSign}
                iconColor="text-secondary"
                iconBgColor="bg-secondary/10"
              />
            </div>
            <div onClick={() => setCurrentView('referrals')} className="cursor-pointer">
              <StatsCard
                title="Total Referrals"
                value={stats.totalReferrals}
                change={`${Math.round(stats.conversionRate)}%`}
                changeLabel="conversion rate"
                icon={TrendingUp}
                iconColor="text-primary"
                iconBgColor="bg-primary/10"
              />
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Student Management */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="students" className="space-y-6">
              <Card>
                <div className="border-b border-gray-200">
                  <TabsList className="h-auto p-0 bg-transparent">
                    <TabsTrigger
                      value="students"
                      className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    >
                      My Students ({students.length})
                    </TabsTrigger>
                    <TabsTrigger
                      value="enrollments"
                      className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    >
                      Course Progress ({enrollments.length})
                    </TabsTrigger>
                    <TabsTrigger
                      value="referrals"
                      className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    >
                      Referrals ({referrals.length})
                    </TabsTrigger>
                    <TabsTrigger
                      value="links"
                      className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    >
                      Link Generator
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="students">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-semibold">Student Management</h3>
                      <Button variant="ghost" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Export List
                      </Button>
                    </div>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student</TableHead>
                            <TableHead>Student ID</TableHead>
                            <TableHead>Experience Level</TableHead>
                            <TableHead>Enrollments</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {students.map((student) => {
                            const studentEnrollments = enrollments.filter(e => e.studentId === student.id);
                            return (
                              <TableRow key={student.id}>
                                <TableCell>
                                  <div className="flex items-center space-x-3">
                                    <Avatar className="w-8 h-8">
                                      <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${student.name}`} />
                                      <AvatarFallback>
                                        {student.name.split(' ').map(n => n[0]).join('')}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="font-medium">{student.name}</div>
                                      <div className="text-sm text-neutral">{student.email}</div>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell className="font-mono text-sm">{student.studentId}</TableCell>
                                <TableCell>
                                  {student.golfExperience ? (
                                    <Badge variant="outline">
                                      {student.golfExperience}
                                    </Badge>
                                  ) : (
                                    <span className="text-neutral">Not specified</span>
                                  )}
                                </TableCell>
                                <TableCell>{studentEnrollments.length}</TableCell>
                                <TableCell>
                                  <Badge className={getStatusColor(student.status)} variant="secondary">
                                    {student.status}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <Button size="sm" variant="ghost">
                                    View Details
                                  </Button>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </TabsContent>

                <TabsContent value="enrollments">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-semibold">Course Progress Tracking</h3>
                    </div>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student</TableHead>
                            <TableHead>Course</TableHead>
                            <TableHead>Progress</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Start Date</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {enrollments.map((enrollment) => {
                            const student = students.find(s => s.id === enrollment.studentId);
                            return (
                              <TableRow key={enrollment.id}>
                                <TableCell>
                                  <div className="text-sm">
                                    <div className="font-medium">{student?.name}</div>
                                    <div className="text-neutral">{student?.studentId}</div>
                                  </div>
                                </TableCell>
                                <TableCell className="text-sm">Course #{enrollment.courseId}</TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <div className="w-20 bg-gray-200 rounded-full h-2">
                                      <div 
                                        className="bg-primary h-2 rounded-full" 
                                        style={{ width: `${enrollment.progress || 0}%` }}
                                      />
                                    </div>
                                    <span className="text-sm font-medium">{enrollment.progress || 0}%</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge className={getStatusColor(enrollment.status)} variant="secondary">
                                    {enrollment.status}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-sm">
                                  {formatDate(enrollment.startDate)}
                                </TableCell>
                                <TableCell>
                                  <Button size="sm" variant="ghost">
                                    <Calendar className="w-4 h-4 mr-1" />
                                    Sessions
                                  </Button>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </TabsContent>

                <TabsContent value="referrals">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-semibold">Referral Management</h3>
                      <Button variant="ghost" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Export Data
                      </Button>
                    </div>
                    <ReferralsTable referrals={referrals} />
                  </CardContent>
                </TabsContent>

                <TabsContent value="links">
                  <div className="p-0">
                    {coach && <LinkGenerator coach={coach} />}
                  </div>
                </TabsContent>
              </Card>
            </Tabs>
          </div>

          {/* Schedule & Quick Actions */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5" />
                  <span>Session Schedule</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CalendarComponent
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full justify-start">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Schedule New Session
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Add New Student
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Share className="w-4 h-4 mr-2" />
                  Generate Referral Link
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-success rounded-full"></div>
                    <div>
                      <div className="font-medium">Session completed</div>
                      <div className="text-neutral">with John Smith - 2 hours ago</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div>
                      <div className="font-medium">New referral</div>
                      <div className="text-neutral">Sarah Johnson signed up - 1 day ago</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-secondary rounded-full"></div>
                    <div>
                      <div className="font-medium">Payout processed</div>
                      <div className="text-neutral">{formatCurrency(450)} - 3 days ago</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Invite Student Modal */}
        <Dialog open={showInviteModal} onOpenChange={setShowInviteModal}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Invite Students</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-gray-600">Share your referral link with potential students:</p>
              
              {inviteUrl && (
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={inviteUrl}
                      readOnly
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    />
                    <Button size="sm" onClick={copyInviteLink}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button onClick={generateQRCode} variant="outline" className="flex-1">
                      <QrCode className="h-4 w-4 mr-2" />
                      Generate QR Code
                    </Button>
                    <Button onClick={copyInviteLink} className="flex-1">
                      <Copy className="h-4 w-4 mr-2" />
                      Copy Link
                    </Button>
                  </div>
                  
                  <p className="text-xs text-gray-500">
                    Students who sign up through this link will be automatically assigned to you and receive a 20% discount.
                  </p>
                </div>
              )}
              
              {!inviteUrl && (
                <p className="text-gray-500">No referral link available. Please contact support.</p>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}