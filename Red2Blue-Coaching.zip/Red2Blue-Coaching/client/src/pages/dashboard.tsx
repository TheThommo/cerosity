import { useState } from "react";
import { Users, GraduationCap, DollarSign, TrendingUp, Share, BarChart, Headphones, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import StatsCard from "@/components/stats-card";
import ReferralsTable from "@/components/referrals-table";
import LinkGenerator from "@/components/link-generator";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/utils";
import type { Coach, Referral } from "@shared/schema";

export default function Dashboard() {
  // Mock coach data - in real app this would come from authentication
  const mockCoach: Coach = {
    id: 1,
    coachId: "PGA-UAE-001",
    name: "John Anderson",
    email: "john.anderson@golf.com",
    password: "",
    certification: "PGA-UAE",
    status: "approved",
    createdAt: new Date(),
  };

  const { data: stats } = useQuery({
    queryKey: [`/api/coaches/${mockCoach.id}/stats`],
  });

  const { data: referrals = [] } = useQuery<Referral[]>({
    queryKey: [`/api/referrals/coach/${mockCoach.id}`],
  });

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <Navigation coach={mockCoach} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary to-blue-600 rounded-xl p-8 mb-8 text-white">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-3xl font-bold mb-4">Welcome to Your Referral Dashboard</h1>
              <p className="text-blue-100 mb-6">
                Manage your golf coaching referrals, track commissions, and grow your network with our integrated platform.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button variant="secondary" className="bg-white text-primary hover:bg-gray-50">
                  Generate Referral Link
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                  View Analytics
                </Button>
              </div>
            </div>
            <div className="text-center">
              <img
                src="https://images.unsplash.com/photo-1535131749006-b7f58c99034b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
                alt="Golf course landscape"
                className="rounded-lg shadow-lg mx-auto"
              />
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
              title="Total Referrals"
              value={stats.totalReferrals}
              change="+12%"
              changeLabel="vs last month"
              icon={Users}
              iconColor="text-primary"
              iconBgColor="bg-primary/10"
            />
            <StatsCard
              title="Active Students"
              value={stats.activeStudents}
              change="+8%"
              changeLabel="conversion rate"
              icon={GraduationCap}
              iconColor="text-success"
              iconBgColor="bg-success/10"
            />
            <StatsCard
              title="Pending Payout"
              value={formatCurrency(stats.pendingPayout)}
              changeLabel="Next payout: Dec 15"
              icon={DollarSign}
              iconColor="text-secondary"
              iconBgColor="bg-secondary/10"
            />
            <StatsCard
              title="Conversion Rate"
              value={`${Math.round(stats.conversionRate)}%`}
              change="Above average"
              changeLabel="industry: 65%"
              icon={TrendingUp}
              iconColor="text-primary"
              iconBgColor="bg-primary/10"
            />
          </div>
        )}

        {/* Tabbed Interface */}
        <Tabs defaultValue="referrals" className="space-y-6">
          <Card>
            <div className="border-b border-gray-200">
              <TabsList className="h-auto p-0 bg-transparent">
                <TabsTrigger
                  value="referrals"
                  className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                >
                  Referral Management
                </TabsTrigger>
                <TabsTrigger
                  value="links"
                  className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                >
                  Link Generator
                </TabsTrigger>
                <TabsTrigger
                  value="analytics"
                  className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                >
                  Analytics
                </TabsTrigger>
                <TabsTrigger
                  value="payouts"
                  className="py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                >
                  Payouts
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="referrals">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold">Recent Referrals</h3>
                  <Button variant="ghost" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Export Data
                  </Button>
                </div>
                <ReferralsTable referrals={referrals} />
              </CardContent>
            </TabsContent>

            <TabsContent value="links">
              <div className="p-0">
                <LinkGenerator coach={mockCoach} />
              </div>
            </TabsContent>

            <TabsContent value="analytics">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Analytics Dashboard</h3>
                <p className="text-neutral">Analytics features coming soon...</p>
              </CardContent>
            </TabsContent>

            <TabsContent value="payouts">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Payout Management</h3>
                <p className="text-neutral">Payout features coming soon...</p>
              </CardContent>
            </TabsContent>
          </Card>
        </Tabs>

        {/* Quick Actions Section */}
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Share className="text-primary w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Share on Social Media</h4>
              <p className="text-sm text-neutral mb-4">
                Promote your coaching services with pre-made social media posts
              </p>
              <Button variant="ghost" className="text-primary hover:text-blue-700">
                Get Share Templates →
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-success/10 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <BarChart className="text-success w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Performance Report</h4>
              <p className="text-sm text-neutral mb-4">
                Download detailed analytics and performance metrics
              </p>
              <Button variant="ghost" className="text-primary hover:text-blue-700">
                Download Report →
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-secondary/10 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Headphones className="text-secondary w-6 h-6" />
              </div>
              <h4 className="font-semibold mb-2">Support & Training</h4>
              <p className="text-sm text-neutral mb-4">
                Access coaching resources and platform tutorials
              </p>
              <Button variant="ghost" className="text-primary hover:text-blue-700">
                Get Help →
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
