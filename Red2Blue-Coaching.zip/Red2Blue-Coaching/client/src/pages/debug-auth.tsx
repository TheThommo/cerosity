import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";

export default function DebugAuth() {
  const { user, isLoading, isAuthenticated } = useAuth();
  
  const { data: rawResponse } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold mb-6">Authentication Debug</h1>
        
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold">Loading State:</h3>
            <p>{isLoading ? "Loading..." : "Complete"}</p>
          </div>
          
          <div>
            <h3 className="font-semibold">Is Authenticated:</h3>
            <p>{isAuthenticated ? "Yes" : "No"}</p>
          </div>
          
          <div>
            <h3 className="font-semibold">User Data:</h3>
            <pre className="bg-gray-100 p-3 rounded text-sm">
              {JSON.stringify(user, null, 2)}
            </pre>
          </div>
          
          <div>
            <h3 className="font-semibold">Raw API Response:</h3>
            <pre className="bg-gray-100 p-3 rounded text-sm">
              {JSON.stringify(rawResponse, null, 2)}
            </pre>
          </div>
          
          <div>
            <h3 className="font-semibold">Current URL:</h3>
            <p>{window.location.href}</p>
          </div>
        </div>
      </div>
    </div>
  );
}