import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Users, GraduationCap, BookOpen, DollarSign, Edit, Trash2, Eye, Check, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Coach, Student, Course, Enrollment } from "@shared/schema";

interface AdminStats {
  totalCoaches: number;
  totalStudents: number;
  totalEnrollments: number;
  completedCourses: number;
  totalRevenue: number;
}

export default function EnhancedAdmin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [showCoachForm, setShowCoachForm] = useState(false);
  const [showCourseForm, setShowCourseForm] = useState(false);

  // Data queries
  const { data: stats } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
  });

  const { data: coaches = [] } = useQuery<Coach[]>({
    queryKey: ["/api/coaches"],
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  // Mutations for creating data
  const createCoachMutation = useMutation({
    mutationFn: async (coachData: any) => {
      const response = await apiRequest("POST", "/api/coaches/register", coachData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/coaches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      setShowCoachForm(false);
      toast({ title: "Coach created successfully" });
    },
  });

  const createCourseMutation = useMutation({
    mutationFn: async (courseData: any) => {
      const response = await apiRequest("POST", "/api/courses", courseData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      setShowCourseForm(false);
      toast({ title: "Course created successfully" });
    },
  });

  const approveCoachMutation = useMutation({
    mutationFn: async (coachId: number) => {
      const response = await apiRequest("PATCH", `/api/coaches/${coachId}/status`, { status: "approved" });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/coaches"] });
      toast({ title: "Coach approved successfully" });
    },
  });

  const CoachForm = () => {
    const [formData, setFormData] = useState({
      name: "",
      email: "",
      password: "coach123",
      certification: "",
      phone: "",
      bio: "",
      yearsExperience: "",
      specializations: "",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      createCoachMutation.mutate({
        ...formData,
        yearsExperience: parseInt(formData.yearsExperience),
        specializations: JSON.stringify(formData.specializations.split(",").map(s => s.trim())),
      });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="certification">Certification</Label>
            <Input
              id="certification"
              value={formData.certification}
              onChange={(e) => setFormData({ ...formData, certification: e.target.value })}
              placeholder="e.g., PGA-UAE"
              required
            />
          </div>
          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="e.g., +971-50-123-4567"
              required
            />
          </div>
        </div>
        <div>
          <Label htmlFor="yearsExperience">Years of Experience</Label>
          <Input
            id="yearsExperience"
            type="number"
            value={formData.yearsExperience}
            onChange={(e) => setFormData({ ...formData, yearsExperience: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="specializations">Specializations (comma-separated)</Label>
          <Input
            id="specializations"
            value={formData.specializations}
            onChange={(e) => setFormData({ ...formData, specializations: e.target.value })}
            placeholder="e.g., Swing Analysis, Short Game, Mental Coaching"
          />
        </div>
        <div>
          <Label htmlFor="bio">Bio</Label>
          <Textarea
            id="bio"
            value={formData.bio}
            onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
            placeholder="Brief description of coaching experience"
          />
        </div>
        <Button type="submit" className="w-full" disabled={createCoachMutation.isPending}>
          {createCoachMutation.isPending ? "Creating..." : "Create Coach"}
        </Button>
      </form>
    );
  };

  const CourseForm = () => {
    const [formData, setFormData] = useState({
      courseId: "",
      name: "",
      description: "",
      duration: "",
      sessionsPerWeek: "",
      totalSessions: "",
      price: "",
      level: "beginner",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      createCourseMutation.mutate({
        ...formData,
        duration: parseInt(formData.duration),
        sessionsPerWeek: parseInt(formData.sessionsPerWeek),
        totalSessions: parseInt(formData.totalSessions),
      });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="courseId">Course ID</Label>
            <Input
              id="courseId"
              value={formData.courseId}
              onChange={(e) => setFormData({ ...formData, courseId: e.target.value })}
              placeholder="e.g., BGF001"
              required
            />
          </div>
          <div>
            <Label htmlFor="level">Level</Label>
            <Select value={formData.level} onValueChange={(value) => setFormData({ ...formData, level: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label htmlFor="name">Course Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            required
          />
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <Label htmlFor="duration">Duration (weeks)</Label>
            <Input
              id="duration"
              type="number"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
              required
            />
          </div>
          <div>
            <Label htmlFor="sessionsPerWeek">Sessions per Week</Label>
            <Input
              id="sessionsPerWeek"
              type="number"
              value={formData.sessionsPerWeek}
              onChange={(e) => setFormData({ ...formData, sessionsPerWeek: e.target.value })}
              required
            />
          </div>
          <div>
            <Label htmlFor="totalSessions">Total Sessions</Label>
            <Input
              id="totalSessions"
              type="number"
              value={formData.totalSessions}
              onChange={(e) => setFormData({ ...formData, totalSessions: e.target.value })}
              required
            />
          </div>
        </div>
        <div>
          <Label htmlFor="price">Price (AED)</Label>
          <Input
            id="price"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            placeholder="e.g., 750.00"
            required
          />
        </div>
        <Button type="submit" className="w-full" disabled={createCourseMutation.isPending}>
          {createCourseMutation.isPending ? "Creating..." : "Create Course"}
        </Button>
      </form>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600">Welcome back, {user?.name}</p>
            </div>
            <div className="flex space-x-4">
              <Dialog open={showCoachForm} onOpenChange={setShowCoachForm}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Coach
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create New Coach</DialogTitle>
                  </DialogHeader>
                  <CoachForm />
                </DialogContent>
              </Dialog>

              <Dialog open={showCourseForm} onOpenChange={setShowCourseForm}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Course
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create New Course</DialogTitle>
                  </DialogHeader>
                  <CourseForm />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Coaches</CardTitle>
              <Users className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalCoaches || 0}</div>
              <p className="text-xs text-muted-foreground">
                {coaches.filter(c => c.status === 'approved').length} approved
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <GraduationCap className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalStudents || 0}</div>
              <p className="text-xs text-muted-foreground">
                {students.filter(s => s.status === 'active').length} active
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Courses</CardTitle>
              <BookOpen className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{courses.length}</div>
              <p className="text-xs text-muted-foreground">Available courses</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Enrollments</CardTitle>
              <BookOpen className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalEnrollments || 0}</div>
              <p className="text-xs text-muted-foreground">
                {enrollments.filter(e => e.status === 'in_progress').length} active
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">AED {stats?.totalRevenue || 0}</div>
              <p className="text-xs text-muted-foreground">Total generated</p>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
          {[
            { id: "coaches", label: "Coaches", count: coaches.length },
            { id: "students", label: "Students", count: students.length },
            { id: "courses", label: "Courses", count: courses.length },
            { id: "enrollments", label: "Enrollments", count: enrollments.length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === tab.id
                  ? "bg-white text-blue-600 shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>

        {/* Content Sections */}
        {activeTab === "coaches" && (
          <Card>
            <CardHeader>
              <CardTitle>Coach Management</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Certification</TableHead>
                    <TableHead>Experience</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {coaches.map((coach) => (
                    <TableRow key={coach.id}>
                      <TableCell className="font-medium">{coach.name}</TableCell>
                      <TableCell>{coach.email}</TableCell>
                      <TableCell>{coach.certification}</TableCell>
                      <TableCell>{coach.yearsExperience} years</TableCell>
                      <TableCell>
                        <Badge variant={coach.status === 'approved' ? 'default' : 'secondary'}>
                          {coach.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {coach.status === 'pending' && (
                          <Button
                            size="sm"
                            onClick={() => approveCoachMutation.mutate(coach.id)}
                            disabled={approveCoachMutation.isPending}
                          >
                            <Check className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                  {coaches.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No coaches found. Create your first coach using the "Add Coach" button.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {activeTab === "students" && (
          <Card>
            <CardHeader>
              <CardTitle>Student Management</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Experience Level</TableHead>
                    <TableHead>Coach</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date Joined</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((student) => {
                    const coach = coaches.find(c => c.id === student.coachId);
                    return (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell>{student.email}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{student.golfExperience}</Badge>
                        </TableCell>
                        <TableCell>{coach?.name || "Unassigned"}</TableCell>
                        <TableCell>
                          <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                            {student.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatDate(student.createdAt || new Date())}</TableCell>
                      </TableRow>
                    );
                  })}
                  {students.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No students enrolled yet. Students will appear here when they register.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {activeTab === "courses" && (
          <Card>
            <CardHeader>
              <CardTitle>Course Management</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Course ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Level</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Sessions</TableHead>
                    <TableHead>Price</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {courses.map((course) => (
                    <TableRow key={course.id}>
                      <TableCell className="font-medium">{course.courseId}</TableCell>
                      <TableCell>{course.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{course.level}</Badge>
                      </TableCell>
                      <TableCell>{course.duration} weeks</TableCell>
                      <TableCell>{course.totalSessions} sessions</TableCell>
                      <TableCell>AED {course.price}</TableCell>
                    </TableRow>
                  ))}
                  {courses.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No courses available. Create your first course using the "Add Course" button.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {activeTab === "enrollments" && (
          <Card>
            <CardHeader>
              <CardTitle>Enrollment Management</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Course</TableHead>
                    <TableHead>Coach</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {enrollments.map((enrollment) => {
                    const student = students.find(s => s.id === enrollment.studentId);
                    const course = courses.find(c => c.id === enrollment.courseId);
                    const coach = coaches.find(c => c.id === enrollment.coachId);
                    return (
                      <TableRow key={enrollment.id}>
                        <TableCell className="font-medium">{student?.name || "Unknown"}</TableCell>
                        <TableCell>{course?.name || "Unknown"}</TableCell>
                        <TableCell>{coach?.name || "Unknown"}</TableCell>
                        <TableCell>{formatDate(enrollment.startDate)}</TableCell>
                        <TableCell>{enrollment.progress || 0}%</TableCell>
                        <TableCell>
                          <Badge variant={enrollment.status === 'in_progress' ? 'default' : 'secondary'}>
                            {enrollment.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  {enrollments.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No enrollments found. Enrollments will appear here when students join courses.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}