import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Users, Calendar, DollarSign, TrendingUp, Edit, Eye, Clock, UserPlus, Copy, QrCode } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/utils";
import NavigationHeader from "@/components/navigation-header";
import type { Coach, Student, Enrollment, Session, ReferralLink, Referral } from "@shared/schema";

interface CoachStats {
  totalReferrals: number;
  activeStudents: number;
  pendingPayout: number;
  conversionRate: number;
}

export default function EnhancedCoach() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [showSessionForm, setShowSessionForm] = useState(false);
  const [showReferralForm, setShowReferralForm] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [selectedEnrollment, setSelectedEnrollment] = useState<Enrollment | null>(null);

  // Data queries
  const { data: coach } = useQuery<Coach>({
    queryKey: [`/api/coaches/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: stats } = useQuery<CoachStats>({
    queryKey: [`/api/coaches/${user?.id}/stats`],
    enabled: !!user?.id,
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  const { data: sessions = [] } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
  });

  const { data: referralLinks = [] } = useQuery<ReferralLink[]>({
    queryKey: [`/api/referral-links/coach/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: referrals = [] } = useQuery<Referral[]>({
    queryKey: [`/api/referrals/coach/${user?.id}`],
    enabled: !!user?.id,
  });

  // Filter data for this coach
  const myStudents = students.filter((student: Student) => student.coachId === user?.id);
  const myEnrollments = enrollments.filter((enrollment: Enrollment) => enrollment.coachId === user?.id);
  const mySessions = sessions.filter((session: Session) => 
    myEnrollments.some(e => e.id === session.enrollmentId)
  );

  // Get the default referral link for inviting students
  const defaultReferralLink = referralLinks.find(link => link.linkId.includes('default')) || referralLinks[0];
  const inviteUrl = defaultReferralLink ? `${window.location.origin}/signup?ref=${defaultReferralLink.linkId}` : null;

  const copyInviteLink = () => {
    if (inviteUrl) {
      navigator.clipboard.writeText(inviteUrl);
      toast({
        title: "Link Copied!",
        description: "Referral link copied to clipboard",
      });
    }
  };

  const generateQRCode = () => {
    if (inviteUrl) {
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(inviteUrl)}`;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head><title>QR Code - Invite Students</title></head>
            <body style="text-align: center; padding: 20px; font-family: Arial, sans-serif;">
              <h2>Share this QR Code with Students</h2>
              <img src="${qrUrl}" alt="QR Code" style="border: 1px solid #ccc; padding: 10px;" />
              <p style="margin-top: 20px; font-size: 12px; color: #666;">
                Students can scan this code to sign up with your referral link
              </p>
              <p style="font-size: 10px; color: #999; margin-top: 20px;">
                ${inviteUrl}
              </p>
            </body>
          </html>
        `);
      }
    }
  };

  // Mutations
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      const response = await apiRequest("POST", "/api/sessions", sessionData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      setShowSessionForm(false);
      toast({ title: "Session scheduled successfully" });
    },
  });

  const createReferralLinkMutation = useMutation({
    mutationFn: async (linkData: any) => {
      const response = await apiRequest("POST", "/api/referral-links", linkData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/referral-links/coach/${user?.id}`] });
      setShowReferralForm(false);
      toast({ title: "Referral link created successfully" });
    },
  });

  const updateSessionMutation = useMutation({
    mutationFn: async ({ sessionId, feedback }: { sessionId: number; feedback: any }) => {
      const response = await apiRequest("PATCH", `/api/sessions/${sessionId}/feedback`, feedback);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({ title: "Session feedback updated" });
    },
  });

  const SessionForm = () => {
    const [formData, setFormData] = useState({
      enrollmentId: selectedEnrollment?.id || "",
      sessionNumber: "",
      scheduledDate: "",
      notes: "",
      skillsWorkedOn: "",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      createSessionMutation.mutate({
        ...formData,
        enrollmentId: parseInt(formData.enrollmentId.toString()),
        sessionNumber: parseInt(formData.sessionNumber),
        scheduledDate: new Date(formData.scheduledDate),
        skillsWorkedOn: JSON.stringify(formData.skillsWorkedOn.split(",").map(s => s.trim())),
        status: "scheduled",
      });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="enrollmentId">Select Student Enrollment</Label>
          <Select 
            value={formData.enrollmentId.toString()} 
            onValueChange={(value) => setFormData({ ...formData, enrollmentId: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Choose an enrollment" />
            </SelectTrigger>
            <SelectContent>
              {myEnrollments.map((enrollment) => {
                const student = students.find(s => s.id === enrollment.studentId);
                return (
                  <SelectItem key={enrollment.id} value={enrollment.id.toString()}>
                    {student?.name} - {enrollment.courseId}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="sessionNumber">Session Number</Label>
          <Input
            id="sessionNumber"
            type="number"
            value={formData.sessionNumber}
            onChange={(e) => setFormData({ ...formData, sessionNumber: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="scheduledDate">Scheduled Date</Label>
          <Input
            id="scheduledDate"
            type="datetime-local"
            value={formData.scheduledDate}
            onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="skillsWorkedOn">Skills to Work On (comma-separated)</Label>
          <Input
            id="skillsWorkedOn"
            value={formData.skillsWorkedOn}
            onChange={(e) => setFormData({ ...formData, skillsWorkedOn: e.target.value })}
            placeholder="e.g., putting, driving, chipping"
          />
        </div>
        <div>
          <Label htmlFor="notes">Session Notes</Label>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            placeholder="Add any notes about the session..."
          />
        </div>
        <Button type="submit" className="w-full" disabled={createSessionMutation.isPending}>
          {createSessionMutation.isPending ? "Scheduling..." : "Schedule Session"}
        </Button>
      </form>
    );
  };

  const ReferralLinkForm = () => {
    const [formData, setFormData] = useState({
      campaignName: "",
      courseId: "",
      utmParams: "",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      createReferralLinkMutation.mutate({
        ...formData,
        coachId: user?.id,
      });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="campaignName">Campaign Name</Label>
          <Input
            id="campaignName"
            value={formData.campaignName}
            onChange={(e) => setFormData({ ...formData, campaignName: e.target.value })}
            placeholder="e.g., Summer Golf Special"
            required
          />
        </div>
        <div>
          <Label htmlFor="courseId">Target Course (Optional)</Label>
          <Input
            id="courseId"
            value={formData.courseId}
            onChange={(e) => setFormData({ ...formData, courseId: e.target.value })}
            placeholder="e.g., GOLF101"
          />
        </div>
        <div>
          <Label htmlFor="utmParams">UTM Parameters (Optional)</Label>
          <Input
            id="utmParams"
            value={formData.utmParams}
            onChange={(e) => setFormData({ ...formData, utmParams: e.target.value })}
            placeholder="e.g., utm_source=social&utm_medium=facebook"
          />
        </div>
        <Button type="submit" className="w-full" disabled={createReferralLinkMutation.isPending}>
          {createReferralLinkMutation.isPending ? "Creating..." : "Create Referral Link"}
        </Button>
      </form>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader 
        title="Coach Dashboard"
        customActions={
          <div className="flex space-x-4">
            <Dialog open={showSessionForm} onOpenChange={setShowSessionForm}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Schedule Session
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Schedule New Session</DialogTitle>
                </DialogHeader>
                <SessionForm />
              </DialogContent>
            </Dialog>

            <Dialog open={showReferralForm} onOpenChange={setShowReferralForm}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Referral Link
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Referral Link</DialogTitle>
                </DialogHeader>
                <ReferralLinkForm />
              </DialogContent>
            </Dialog>
          </div>
        }
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">My Students</CardTitle>
              <Users className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{myStudents.length}</div>
              <p className="text-xs text-muted-foreground">
                {myStudents.filter(s => s.status === 'active').length} active
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Sessions</CardTitle>
              <Calendar className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mySessions.length}</div>
              <p className="text-xs text-muted-foreground">
                {mySessions.filter(s => s.status === 'scheduled').length} scheduled
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Referrals</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{referrals.length}</div>
              <p className="text-xs text-muted-foreground">
                {referrals.filter(r => r.status === 'converted').length} converted
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Payout</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(stats?.pendingPayout || 0)}</div>
              <p className="text-xs text-muted-foreground">From referrals</p>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-4 mb-6">
          <Button 
            variant={activeTab === "overview" ? "default" : "outline"}
            onClick={() => setActiveTab("overview")}
          >
            Overview
          </Button>
          <Button 
            variant={activeTab === "students" ? "default" : "outline"}
            onClick={() => setActiveTab("students")}
          >
            My Students
          </Button>
          <Button 
            variant={activeTab === "sessions" ? "default" : "outline"}
            onClick={() => setActiveTab("sessions")}
          >
            Sessions
          </Button>
          <Button 
            variant={activeTab === "referrals" ? "default" : "outline"}
            onClick={() => setActiveTab("referrals")}
          >
            Referral Links
          </Button>
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mySessions.slice(0, 5).map((session) => {
                    const enrollment = enrollments.find(e => e.id === session.enrollmentId);
                    const student = students.find(s => s.id === enrollment?.studentId);
                    return (
                      <div key={session.id} className="flex items-center justify-between p-3 border rounded">
                        <div>
                          <p className="font-medium">{student?.name}</p>
                          <p className="text-sm text-gray-600">
                            Session {session.sessionNumber} - {formatDate(session.scheduledDate)}
                          </p>
                        </div>
                        <Badge variant={
                          session.status === 'completed' ? 'default' :
                          session.status === 'scheduled' ? 'secondary' : 'outline'
                        }>
                          {session.status}
                        </Badge>
                      </div>
                    );
                  })}
                  {mySessions.length === 0 && (
                    <p className="text-gray-500 text-center py-8">No sessions scheduled yet.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "students" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Students</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Student ID</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {myStudents.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell>{student.studentId}</TableCell>
                        <TableCell>{student.email}</TableCell>
                        <TableCell>
                          <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                            {student.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatDate(student.createdAt)}</TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const enrollment = myEnrollments.find(e => e.studentId === student.id);
                              if (enrollment) {
                                setSelectedEnrollment(enrollment);
                                setShowSessionForm(true);
                              }
                            }}
                          >
                            <Calendar className="w-4 h-4 mr-1" />
                            Schedule
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {myStudents.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-gray-500">
                          No students assigned yet. Share your referral links to start attracting students.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "sessions" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Sessions</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Session #</TableHead>
                      <TableHead>Scheduled Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Skills</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mySessions.map((session) => {
                      const enrollment = enrollments.find(e => e.id === session.enrollmentId);
                      const student = students.find(s => s.id === enrollment?.studentId);
                      return (
                        <TableRow key={session.id}>
                          <TableCell className="font-medium">{student?.name}</TableCell>
                          <TableCell>{session.sessionNumber}</TableCell>
                          <TableCell>{formatDate(session.scheduledDate)}</TableCell>
                          <TableCell>
                            <Badge variant={
                              session.status === 'completed' ? 'default' :
                              session.status === 'scheduled' ? 'secondary' : 'outline'
                            }>
                              {session.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {session.skillsWorkedOn ? 
                              JSON.parse(session.skillsWorkedOn).join(', ') : 
                              'Not specified'
                            }
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm">
                                <Edit className="w-4 h-4 mr-1" />
                                Edit
                              </Button>
                              <Button variant="outline" size="sm">
                                <Eye className="w-4 h-4 mr-1" />
                                View
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {mySessions.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-gray-500">
                          No sessions scheduled yet. Use the "Schedule Session" button to add your first session.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "referrals" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Referral Links</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Campaign</TableHead>
                      <TableHead>Link ID</TableHead>
                      <TableHead>Course</TableHead>
                      <TableHead>Clicks</TableHead>
                      <TableHead>Conversions</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {referralLinks.map((link) => (
                      <TableRow key={link.id}>
                        <TableCell className="font-medium">{link.campaignName}</TableCell>
                        <TableCell className="font-mono text-sm">{link.linkId}</TableCell>
                        <TableCell>{link.courseId || 'All courses'}</TableCell>
                        <TableCell>{(link as any).clickCount || 0}</TableCell>
                        <TableCell>{(link as any).conversionCount || 0}</TableCell>
                        <TableCell>{formatDate(link.createdAt)}</TableCell>
                        <TableCell>
                          <Badge variant={link.isActive ? 'default' : 'secondary'}>
                            {link.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                    {referralLinks.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-gray-500">
                          No referral links created yet. Use the "Create Referral Link" button to get started.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Referral Conversions</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Campaign</TableHead>
                      <TableHead>Referral Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Commission</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {referrals.map((referral) => {
                      const link = referralLinks.find(l => l.id === referral.linkId);
                      const student = students.find(s => s.id === referral.studentId);
                      return (
                        <TableRow key={referral.id}>
                          <TableCell className="font-medium">{student?.name}</TableCell>
                          <TableCell>{link?.campaignName}</TableCell>
                          <TableCell>{formatDate(referral.createdAt)}</TableCell>
                          <TableCell>
                            <Badge variant={referral.status === 'converted' ? 'default' : 'secondary'}>
                              {referral.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{formatCurrency(referral.commissionAmount || 0)}</TableCell>
                        </TableRow>
                      );
                    })}
                    {referrals.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-gray-500">
                          No referral conversions yet. Share your referral links to start earning commissions.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}