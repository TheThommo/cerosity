import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Users, Calendar, DollarSign, TrendingUp, Edit, Eye, Clock, UserPlus, Copy, QrCode } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/utils";
import NavigationHeader from "@/components/navigation-header";
import type { Coach, Student, Enrollment, Session, ReferralLink, Referral } from "@shared/schema";

interface CoachStats {
  totalReferrals: number;
  activeStudents: number;
  pendingPayout: number;
  conversionRate: number;
}

export default function EnhancedCoach() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [showSessionForm, setShowSessionForm] = useState(false);
  const [showReferralForm, setShowReferralForm] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [selectedEnrollment, setSelectedEnrollment] = useState<Enrollment | null>(null);

  // Data queries
  const { data: coach } = useQuery<Coach>({
    queryKey: [`/api/coaches/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: stats } = useQuery<CoachStats>({
    queryKey: [`/api/coaches/${user?.id}/stats`],
    enabled: !!user?.id,
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
  });

  const { data: sessions = [] } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
  });

  const { data: referralLinks = [] } = useQuery<ReferralLink[]>({
    queryKey: [`/api/referral-links/coach/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: referrals = [] } = useQuery<Referral[]>({
    queryKey: [`/api/referrals/coach/${user?.id}`],
    enabled: !!user?.id,
  });

  // Filter data for this coach
  const myStudents = students.filter((student: Student) => student.coachId === user?.id);
  const myEnrollments = enrollments.filter((enrollment: Enrollment) => enrollment.coachId === user?.id);
  const mySessions = sessions.filter((session: Session) => 
    myEnrollments.some(e => e.id === session.enrollmentId)
  );

  // Get the default referral link for inviting students
  const defaultReferralLink = referralLinks.find(link => link.linkId.includes('default')) || referralLinks[0];
  const inviteUrl = defaultReferralLink ? `${window.location.origin}/signup?ref=${defaultReferralLink.linkId}` : null;

  const copyInviteLink = () => {
    if (inviteUrl) {
      navigator.clipboard.writeText(inviteUrl);
      toast({
        title: "Link Copied!",
        description: "Referral link copied to clipboard",
      });
    }
  };

  const generateQRCode = () => {
    if (inviteUrl) {
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(inviteUrl)}`;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head><title>QR Code - Invite Students</title></head>
            <body style="text-align: center; padding: 20px; font-family: Arial, sans-serif;">
              <h2>Share this QR Code with Students</h2>
              <img src="${qrUrl}" alt="QR Code" style="border: 1px solid #ccc; padding: 10px;" />
              <p style="margin-top: 20px; font-size: 12px; color: #666;">
                Students can scan this code to sign up with your referral link
              </p>
              <p style="font-size: 10px; color: #999; margin-top: 20px;">
                ${inviteUrl}
              </p>
            </body>
          </html>
        `);
      }
    }
  };

  // Mutations
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      const response = await apiRequest("POST", "/api/sessions", sessionData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      setShowSessionForm(false);
      toast({ title: "Session scheduled successfully" });
    },
  });

  const createReferralLinkMutation = useMutation({
    mutationFn: async (linkData: any) => {
      const response = await apiRequest("POST", "/api/referral-links", linkData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/referral-links/coach/${user?.id}`] });
      setShowReferralForm(false);
      toast({ title: "Referral link created successfully" });
    },
  });

  // Navigation functions for clickable cards
  const goToStudentsView = () => {
    setActiveTab("students");
  };

  const goToReferralsView = () => {
    setActiveTab("referrals");
  };

  const SessionForm = () => {
    const [formData, setFormData] = useState({
      enrollmentId: selectedEnrollment?.id || "",
      sessionNumber: "",
      scheduledDate: "",
      notes: "",
      skillsWorkedOn: "",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      createSessionMutation.mutate({
        ...formData,
        enrollmentId: Number(formData.enrollmentId),
        sessionNumber: Number(formData.sessionNumber),
      });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="enrollmentId">Student Enrollment</Label>
          <Select value={formData.enrollmentId.toString()} onValueChange={(value) => setFormData(prev => ({...prev, enrollmentId: value}))}>
            <SelectTrigger>
              <SelectValue placeholder="Select student enrollment" />
            </SelectTrigger>
            <SelectContent>
              {myEnrollments.map((enrollment) => {
                const student = students.find(s => s.id === enrollment.studentId);
                return (
                  <SelectItem key={enrollment.id} value={enrollment.id.toString()}>
                    {student?.name} - {enrollment.courseId}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="sessionNumber">Session Number</Label>
          <Input
            type="number"
            value={formData.sessionNumber}
            onChange={(e) => setFormData(prev => ({...prev, sessionNumber: e.target.value}))}
            required
          />
        </div>

        <div>
          <Label htmlFor="scheduledDate">Scheduled Date</Label>
          <Input
            type="datetime-local"
            value={formData.scheduledDate}
            onChange={(e) => setFormData(prev => ({...prev, scheduledDate: e.target.value}))}
            required
          />
        </div>

        <div>
          <Label htmlFor="skillsWorkedOn">Skills to Work On</Label>
          <Textarea
            value={formData.skillsWorkedOn}
            onChange={(e) => setFormData(prev => ({...prev, skillsWorkedOn: e.target.value}))}
            placeholder="Enter skills to focus on in this session"
          />
        </div>

        <div>
          <Label htmlFor="notes">Session Notes</Label>
          <Textarea
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({...prev, notes: e.target.value}))}
            placeholder="Additional notes for this session"
          />
        </div>

        <Button type="submit" disabled={createSessionMutation.isPending}>
          {createSessionMutation.isPending ? "Creating..." : "Schedule Session"}
        </Button>
      </form>
    );
  };

  const ReferralLinkForm = () => {
    const [linkData, setLinkData] = useState({
      campaign: "",
      utmSource: "",
      utmMedium: "",
      utmCampaign: "",
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      createReferralLinkMutation.mutate(linkData);
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="campaign">Campaign Name</Label>
          <Input
            value={linkData.campaign}
            onChange={(e) => setLinkData(prev => ({...prev, campaign: e.target.value}))}
            placeholder="e.g., Summer Golf Program"
            required
          />
        </div>

        <div>
          <Label htmlFor="utmSource">UTM Source</Label>
          <Input
            value={linkData.utmSource}
            onChange={(e) => setLinkData(prev => ({...prev, utmSource: e.target.value}))}
            placeholder="e.g., facebook, instagram"
          />
        </div>

        <div>
          <Label htmlFor="utmMedium">UTM Medium</Label>
          <Input
            value={linkData.utmMedium}
            onChange={(e) => setLinkData(prev => ({...prev, utmMedium: e.target.value}))}
            placeholder="e.g., social, email"
          />
        </div>

        <div>
          <Label htmlFor="utmCampaign">UTM Campaign</Label>
          <Input
            value={linkData.utmCampaign}
            onChange={(e) => setLinkData(prev => ({...prev, utmCampaign: e.target.value}))}
            placeholder="e.g., summer2024"
          />
        </div>

        <Button type="submit" disabled={createReferralLinkMutation.isPending}>
          {createReferralLinkMutation.isPending ? "Creating..." : "Create Link"}
        </Button>
      </form>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader 
        title="Coach Dashboard"
        customActions={
          <div className="flex space-x-2">
            {/* Invite Student Button */}
            <Button 
              onClick={() => setShowInviteModal(true)}
              disabled={!inviteUrl}
              className="bg-primary hover:bg-primary/90"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Invite Student
            </Button>
            
            <Dialog open={showSessionForm} onOpenChange={setShowSessionForm}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Schedule Session
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Schedule New Session</DialogTitle>
                </DialogHeader>
                <SessionForm />
              </DialogContent>
            </Dialog>

            <Dialog open={showReferralForm} onOpenChange={setShowReferralForm}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Referral Link
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Referral Link</DialogTitle>
                </DialogHeader>
                <ReferralLinkForm />
              </DialogContent>
            </Dialog>
          </div>
        }
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats Overview - Now clickable */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={goToStudentsView}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">My Students</CardTitle>
              <Users className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{myStudents.length}</div>
              <p className="text-xs text-muted-foreground">
                {myStudents.filter(s => s.status === 'active').length} active
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab("sessions")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Sessions</CardTitle>
              <Calendar className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mySessions.length}</div>
              <p className="text-xs text-muted-foreground">
                {mySessions.filter(s => s.status === 'scheduled').length} scheduled
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab("payouts")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Payout</CardTitle>
              <DollarSign className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(stats?.pendingPayout || 0)}</div>
              <p className="text-xs text-muted-foreground">Next payout: Dec 15</p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={goToReferralsView}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Referrals</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalReferrals || 0}</div>
              <p className="text-xs text-muted-foreground">
                {Math.round(stats?.conversionRate || 0)}% conversion rate
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === "overview" && (
            <Card>
              <CardHeader>
                <CardTitle>Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Welcome to your coaching dashboard! Use the stats cards above to navigate to different sections,
                  or click the "Invite Student" button to share your referral link.
                </p>
              </CardContent>
            </Card>
          )}

          {activeTab === "students" && (
            <Card>
              <CardHeader>
                <CardTitle>My Students ({myStudents.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {myStudents.map((student) => (
                    <div key={student.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold">{student.name}</h3>
                        <p className="text-sm text-gray-600">ID: {student.studentId}</p>
                        <p className="text-sm text-gray-600">{student.email}</p>
                      </div>
                      <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                        {student.status}
                      </Badge>
                    </div>
                  ))}
                  {myStudents.length === 0 && (
                    <p className="text-gray-500 text-center py-8">
                      No students yet. Use the "Invite Student" button to start building your roster!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === "referrals" && (
            <Card>
              <CardHeader>
                <CardTitle>Referral Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {referrals.map((referral) => (
                    <div key={referral.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold">{referral.studentName}</h3>
                        <p className="text-sm text-gray-600">Signup Date: {formatDate(referral.createdAt)}</p>
                      </div>
                      <Badge variant={referral.status === 'converted' ? 'default' : 'secondary'}>
                        {referral.status}
                      </Badge>
                    </div>
                  ))}
                  {referrals.length === 0 && (
                    <p className="text-gray-500 text-center py-8">
                      No referrals yet. Share your referral link to start earning commissions!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Invite Student Modal */}
        <Dialog open={showInviteModal} onOpenChange={setShowInviteModal}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Invite Students</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-gray-600">Share your referral link with potential students:</p>
              
              {inviteUrl && (
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={inviteUrl}
                      readOnly
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    />
                    <Button size="sm" onClick={copyInviteLink}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button onClick={generateQRCode} variant="outline" className="flex-1">
                      <QrCode className="h-4 w-4 mr-2" />
                      Generate QR Code
                    </Button>
                    <Button onClick={copyInviteLink} className="flex-1">
                      <Copy className="h-4 w-4 mr-2" />
                      Copy Link
                    </Button>
                  </div>
                  
                  <p className="text-xs text-gray-500">
                    Students who sign up through this link will be automatically assigned to you and receive a 20% discount.
                  </p>
                </div>
              )}
              
              {!inviteUrl && (
                <p className="text-gray-500">No referral link available. Please contact support.</p>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}