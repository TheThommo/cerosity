import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar, BookOpen, Clock, Star, User, TrendingUp, MessageSquare } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import NavigationHeader from "@/components/navigation-header";
import type { Student, Coach, Course, Enrollment, Session } from "@shared/schema";

export default function EnhancedStudent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);

  // Data queries
  const { data: student } = useQuery<Student>({
    queryKey: [`/api/students/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: [`/api/students/${user?.id}/enrollments`],
    enabled: !!user?.id,
  });

  const { data: allSessions = [] } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
  });

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: coaches = [] } = useQuery<Coach[]>({
    queryKey: ["/api/coaches"],
  });

  // Filter data for this student
  const myEnrollments = enrollments.filter(e => e.studentId === user?.id);
  const mySessions = allSessions.filter(s => {
    const enrollment = myEnrollments.find(e => e.id === s.enrollmentId);
    return !!enrollment;
  });

  const myCoach = coaches.find(c => c.id === student?.coachId);
  const currentEnrollment = myEnrollments.find(e => e.status === 'in_progress');
  const currentCourse = currentEnrollment ? courses.find(c => c.id === currentEnrollment.courseId) : null;

  // Calculate progress stats
  const completedSessions = mySessions.filter(s => s.status === 'completed').length;
  const totalSessions = currentCourse?.totalSessions || 0;
  const progressPercentage = totalSessions > 0 ? (completedSessions / totalSessions) * 100 : 0;

  // Upcoming sessions
  const upcomingSessions = mySessions.filter(s => {
    if (s.status !== 'scheduled') return false;
    const sessionDate = new Date(s.scheduledDate);
    return sessionDate > new Date();
  }).sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime());

  // Recent sessions
  const recentSessions = mySessions.filter(s => s.status === 'completed')
    .sort((a, b) => new Date(b.actualDate || b.scheduledDate).getTime() - new Date(a.actualDate || a.scheduledDate).getTime())
    .slice(0, 5);

  // Mutations
  const submitFeedbackMutation = useMutation({
    mutationFn: async ({ sessionId, feedback, rating }: { sessionId: number; feedback: string; rating: number }) => {
      const response = await apiRequest("PATCH", `/api/sessions/${sessionId}/feedback`, {
        studentFeedback: feedback,
        rating: rating,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      setShowFeedbackForm(false);
      setSelectedSession(null);
      toast({ title: "Feedback submitted successfully" });
    },
  });

  const enrollInCourseMutation = useMutation({
    mutationFn: async (courseId: number) => {
      const response = await apiRequest("POST", "/api/enrollments", {
        studentId: user?.id,
        courseId: courseId,
        coachId: student?.coachId,
        startDate: new Date().toISOString().split('T')[0],
        status: "in_progress",
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/students/${user?.id}/enrollments`] });
      toast({ title: "Successfully enrolled in course" });
    },
  });

  const FeedbackForm = () => {
    const [feedback, setFeedback] = useState("");
    const [rating, setRating] = useState(5);

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (selectedSession) {
        submitFeedbackMutation.mutate({
          sessionId: selectedSession.id,
          feedback,
          rating,
        });
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Session Details</Label>
          <p className="text-sm text-gray-600">
            Session {selectedSession?.sessionNumber} - {formatDate(selectedSession?.scheduledDate || new Date())}
          </p>
        </div>
        <div>
          <Label htmlFor="rating">Rating (1-5 stars)</Label>
          <div className="flex space-x-2 mt-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className={`p-1 ${star <= rating ? 'text-yellow-500' : 'text-gray-300'}`}
              >
                <Star className="w-6 h-6 fill-current" />
              </button>
            ))}
          </div>
        </div>
        <div>
          <Label htmlFor="feedback">Session Feedback</Label>
          <Textarea
            id="feedback"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder="How was your session? What did you learn? Any suggestions?"
            required
          />
        </div>
        <Button type="submit" className="w-full" disabled={submitFeedbackMutation.isPending}>
          {submitFeedbackMutation.isPending ? "Submitting..." : "Submit Feedback"}
        </Button>
      </form>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader 
        title="Student Dashboard"
        customActions={
          myCoach ? (
            <div className="text-sm text-right">
              <p className="text-gray-600">Your Coach</p>
              <p className="font-semibold">{myCoach.name}</p>
              <p className="text-xs text-gray-500">{myCoach.certification}</p>
            </div>
          ) : null
        }
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Current Course Progress */}
        {currentEnrollment && currentCourse && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Current Course Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h3 className="font-semibold text-lg">{currentCourse.name}</h3>
                  <p className="text-gray-600">{currentCourse.description}</p>
                  <Badge variant="outline" className="mt-2">{currentCourse.level}</Badge>
                </div>
                <div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{completedSessions}/{totalSessions} sessions</span>
                    </div>
                    <Progress value={progressPercentage} className="w-full" />
                    <p className="text-sm text-gray-600">{Math.round(progressPercentage)}% complete</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="text-gray-600">Started:</span> {formatDate(currentEnrollment.startDate)}
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600">Duration:</span> {currentCourse.duration} weeks
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600">Sessions per week:</span> {currentCourse.sessionsPerWeek}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Sessions</CardTitle>
              <Calendar className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mySessions.length}</div>
              <p className="text-xs text-muted-foreground">
                {completedSessions} completed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Upcoming</CardTitle>
              <Clock className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{upcomingSessions.length}</div>
              <p className="text-xs text-muted-foreground">
                Next session: {upcomingSessions[0] ? formatDate(upcomingSessions[0].scheduledDate) : 'TBD'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
              <Star className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {mySessions.filter(s => s.rating).length > 0 
                  ? (mySessions.reduce((sum, s) => sum + (s.rating || 0), 0) / mySessions.filter(s => s.rating).length).toFixed(1)
                  : 'N/A'
                }
              </div>
              <p className="text-xs text-muted-foreground">
                {mySessions.filter(s => s.rating).length} ratings given
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Courses</CardTitle>
              <BookOpen className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{myEnrollments.length}</div>
              <p className="text-xs text-muted-foreground">
                {myEnrollments.filter(e => e.status === 'completed').length} completed
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
          {[
            { id: "upcoming", label: "Upcoming Sessions", count: upcomingSessions.length },
            { id: "history", label: "Session History", count: recentSessions.length },
            { id: "courses", label: "My Courses", count: myEnrollments.length },
            { id: "available", label: "Available Courses", count: courses.length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === tab.id
                  ? "bg-white text-blue-600 shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>

        {/* Content Sections */}
        {activeTab === "upcoming" && (
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Session</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Skills Focus</TableHead>
                    <TableHead>Coach Notes</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {upcomingSessions.map((session) => (
                    <TableRow key={session.id}>
                      <TableCell className="font-medium">Session {session.sessionNumber}</TableCell>
                      <TableCell>{formatDate(session.scheduledDate)}</TableCell>
                      <TableCell>
                        {session.skillsWorkedOn ? 
                          JSON.parse(session.skillsWorkedOn).slice(0, 2).join(", ") : 
                          "To be determined"
                        }
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{session.notes || "No notes"}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{session.status}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {upcomingSessions.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-gray-500">
                        No upcoming sessions scheduled. Your coach will schedule sessions for you.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {activeTab === "history" && (
          <Card>
            <CardHeader>
              <CardTitle>Session History</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Session</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Skills Worked</TableHead>
                    <TableHead>Coach Feedback</TableHead>
                    <TableHead>Your Rating</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentSessions.map((session) => (
                    <TableRow key={session.id}>
                      <TableCell className="font-medium">Session {session.sessionNumber}</TableCell>
                      <TableCell>{formatDate(session.actualDate || session.scheduledDate)}</TableCell>
                      <TableCell>
                        {session.skillsWorkedOn ? 
                          JSON.parse(session.skillsWorkedOn).slice(0, 2).join(", ") : 
                          "Not specified"
                        }
                      </TableCell>
                      <TableCell className="max-w-xs truncate">
                        {session.coachFeedback || "No feedback provided"}
                      </TableCell>
                      <TableCell>
                        {session.rating ? (
                          <div className="flex items-center">
                            <Star className="w-4 h-4 text-yellow-500 fill-current mr-1" />
                            {session.rating}
                          </div>
                        ) : (
                          "Not rated"
                        )}
                      </TableCell>
                      <TableCell>
                        {!session.studentFeedback && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedSession(session);
                              setShowFeedbackForm(true);
                            }}
                          >
                            <MessageSquare className="w-4 h-4 mr-1" />
                            Feedback
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                  {recentSessions.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No completed sessions yet. Session history will appear here after your first lesson.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {activeTab === "courses" && (
          <Card>
            <CardHeader>
              <CardTitle>My Course Enrollments</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Course</TableHead>
                    <TableHead>Level</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Grade</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {myEnrollments.map((enrollment) => {
                    const course = courses.find(c => c.id === enrollment.courseId);
                    return (
                      <TableRow key={enrollment.id}>
                        <TableCell className="font-medium">{course?.name || "Unknown Course"}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{course?.level}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Progress value={enrollment.progress || 0} className="w-20" />
                            <span className="text-sm">{enrollment.progress || 0}%</span>
                          </div>
                        </TableCell>
                        <TableCell>{formatDate(enrollment.startDate)}</TableCell>
                        <TableCell>
                          <Badge variant={enrollment.status === 'completed' ? 'default' : 'secondary'}>
                            {enrollment.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{enrollment.finalGrade || "Pending"}</TableCell>
                      </TableRow>
                    );
                  })}
                  {myEnrollments.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500">
                        No course enrollments yet. Browse available courses to get started.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {activeTab === "available" && (
          <Card>
            <CardHeader>
              <CardTitle>Available Courses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {courses.map((course) => {
                  const isEnrolled = myEnrollments.some(e => e.courseId === course.id);
                  return (
                    <Card key={course.id} className="relative">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{course.name}</CardTitle>
                            <Badge variant="outline" className="mt-1">{course.level}</Badge>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-lg">AED {course.price}</p>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 text-sm mb-4">{course.description}</p>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Duration:</span>
                            <span>{course.duration} weeks</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Sessions:</span>
                            <span>{course.totalSessions} total</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Frequency:</span>
                            <span>{course.sessionsPerWeek}/week</span>
                          </div>
                        </div>
                        <Button 
                          className="w-full mt-4" 
                          disabled={isEnrolled || enrollInCourseMutation.isPending}
                          onClick={() => enrollInCourseMutation.mutate(course.id)}
                        >
                          {isEnrolled ? "Already Enrolled" : 
                           enrollInCourseMutation.isPending ? "Enrolling..." : "Enroll Now"}
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
                {courses.length === 0 && (
                  <div className="col-span-full text-center text-gray-500">
                    No courses available at the moment. Check back later for new offerings.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Feedback Dialog */}
      <Dialog open={showFeedbackForm} onOpenChange={setShowFeedbackForm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Session Feedback</DialogTitle>
          </DialogHeader>
          <FeedbackForm />
        </DialogContent>
      </Dialog>
    </div>
  );
}