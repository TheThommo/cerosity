import { useState } from "react";
import { useLocation } from "wouter";
import { Club, Users, GraduationCap, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useLogin } from "@/hooks/useAuth";

export default function Login() {
  const [, setLocation] = useLocation();
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [activeTab, setActiveTab] = useState("coach");
  const { toast } = useToast();
  const login = useLogin();

  const handleLogin = async (role: 'admin' | 'coach' | 'student') => {
    if (!credentials.email || !credentials.password) {
      toast({
        title: "All fields required",
        description: "Please enter your email and password.",
        variant: "destructive",
      });
      return;
    }

    try {
      await login.mutateAsync({ ...credentials, role });
      toast({
        title: "Login successful",
        description: "Welcome back!",
      });
      
      // Redirect based on role
      switch (role) {
        case 'admin':
          setLocation("/admin-dashboard");
          break;
        case 'coach':
          setLocation("/coach-dashboard");
          break;
        case 'student':
          setLocation("/student-dashboard");
          break;
      }
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid email or password. Please check your credentials and try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Club className="text-primary text-3xl" />
            <span className="text-2xl font-bold text-primary">Red2Blue Coaching</span>
          </div>
          <h2 className="mt-6 text-3xl font-bold text-foreground">
            Sign In to Your Account
          </h2>
          <p className="mt-2 text-sm text-neutral">
            Access your personalized dashboard and manage your golf coaching experience
          </p>
        </div>

        {/* Login Form */}
        <Card>
          <CardHeader>
            <CardTitle>Choose Your Account Type</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="admin" className="flex items-center space-x-2">
                  <Shield className="w-4 h-4" />
                  <span>Admin</span>
                </TabsTrigger>
                <TabsTrigger value="coach" className="flex items-center space-x-2">
                  <Users className="w-4 h-4" />
                  <span>Coach</span>
                </TabsTrigger>
                <TabsTrigger value="student" className="flex items-center space-x-2">
                  <GraduationCap className="w-4 h-4" />
                  <span>Student</span>
                </TabsTrigger>
              </TabsList>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={credentials.email}
                    onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="Enter your email"
                  />
                </div>

                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={credentials.password}
                    onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                    placeholder="Enter your password"
                  />
                </div>
              </div>

              <TabsContent value="admin" className="space-y-4">
                <div className="bg-red-50 rounded-lg p-4">
                  <h4 className="font-semibold text-red-800 mb-2">Admin Access</h4>
                  <p className="text-sm text-red-700">
                    Full system administration with access to all coaches, students, and platform analytics.
                  </p>
                </div>
                <Button
                  onClick={() => handleLogin('admin')}
                  disabled={login.isPending}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  {login.isPending ? "Signing In..." : "Sign In as Admin"}
                </Button>
              </TabsContent>

              <TabsContent value="coach" className="space-y-4">
                <div className="bg-blue-50 rounded-lg p-4">
                  <h4 className="font-semibold text-primary mb-2">Coach Dashboard</h4>
                  <p className="text-sm text-foreground">
                    Manage your students, track attendance, create referral links, and view your earnings.
                  </p>
                </div>
                <Button
                  onClick={() => handleLogin('coach')}
                  disabled={login.isPending}
                  className="w-full"
                >
                  {login.isPending ? "Signing In..." : "Sign In as Coach"}
                </Button>
              </TabsContent>

              <TabsContent value="student" className="space-y-4">
                <div className="bg-green-50 rounded-lg p-4">
                  <h4 className="font-semibold text-success mb-2">Student Portal</h4>
                  <p className="text-sm text-foreground">
                    View your course progress, attendance records, and upcoming sessions.
                  </p>
                </div>
                <Button
                  onClick={() => handleLogin('student')}
                  disabled={login.isPending}
                  className="w-full bg-success hover:bg-green-600"
                >
                  {login.isPending ? "Signing In..." : "Sign In as Student"}
                </Button>
              </TabsContent>
            </Tabs>

            {/* Dynamic Register Link */}
            {activeTab !== "admin" && (
              <div className="mt-6 text-center">
                <p className="text-sm text-neutral">
                  Need an account?{" "}
                  <button
                    onClick={() => setLocation("/register")}
                    className="text-primary hover:text-blue-700 font-medium"
                  >
                    {activeTab === "coach" ? "Register as a Coach" : "Register as a Student"}
                  </button>
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Demo Credentials */}
        <div className="text-center">
          <details className="text-xs text-neutral">
            <summary className="cursor-pointer hover:text-foreground">Demo Credentials</summary>
            <div className="mt-2 space-y-1">
              <p><strong>Admin:</strong> admin@red2blue.com / admin123</p>
              <p><strong>Coach:</strong> coach@red2blue.com / coach123</p>
              <p><strong>Student:</strong> student@red2blue.com / student123</p>
            </div>
          </details>
        </div>
      </div>
    </div>
  );
}