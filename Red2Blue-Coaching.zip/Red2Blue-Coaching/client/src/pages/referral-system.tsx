import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Copy, ExternalLink, TrendingUp, Users, DollarSign, LinkIcon } from "lucide-react";
import NavigationHeader from "@/components/navigation-header";
import type { ReferralLink, Referral, Payout } from "@shared/schema";

export default function ReferralSystem() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [newLinkName, setNewLinkName] = useState("");

  // Fetch coach's referral links
  const { data: referralLinks = [] } = useQuery<ReferralLink[]>({
    queryKey: ['/api/referral-links/coach', user?.id],
    enabled: !!user?.id && user?.role === 'coach',
  });

  // Fetch coach's referrals
  const { data: referrals = [] } = useQuery<Referral[]>({
    queryKey: ['/api/referrals/coach', user?.id],
    enabled: !!user?.id && user?.role === 'coach',
  });

  // Fetch coach's payouts
  const { data: payouts = [] } = useQuery<Payout[]>({
    queryKey: ['/api/payouts/coach', user?.id],
    enabled: !!user?.id && user?.role === 'coach',
  });

  // Create new referral link
  const createLinkMutation = useMutation({
    mutationFn: async (campaignName: string) => {
      return await apiRequest('/api/referral-links', 'POST', {
        campaignName,
        courseId: 'red2blue-athlete',
        utmParams: `utm_source=coach&utm_medium=referral&utm_campaign=${campaignName.toLowerCase().replace(/\s+/g, '-')}`
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/referral-links/coach'] });
      setNewLinkName("");
      toast({
        title: "Referral Link Created",
        description: "Your new referral link is ready to use!",
      });
    }
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  const generateReferralUrl = (linkId: string) => {
    return `${window.location.origin}/signup?ref=${linkId}`;
  };

  // Calculate statistics
  const totalReferrals = referrals.length;
  const activeReferrals = referrals.filter(r => r.status === 'active').length;
  const completedReferrals = referrals.filter(r => r.status === 'completed').length;
  const totalCommissions = referrals.reduce((sum, r) => sum + parseFloat(r.commissionAmount || '0'), 0);
  const pendingPayouts = payouts.filter(p => p.status === 'pending').reduce((sum, p) => sum + parseFloat(p.amount), 0);

  if (user?.role !== 'coach') {
    return (
      <div className="p-6">
        <div className="text-center">
          <p className="text-gray-500">Referral system is only available for coaches.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <NavigationHeader 
        title="Referral System"
        breadcrumbs={[
          { label: "Dashboard", path: "/" },
          { label: "Referral System" }
        ]}
      />

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Users className="h-4 w-4 text-blue-600" />
              <div className="ml-2">
                <p className="text-sm font-medium text-gray-600">Total Referrals</p>
                <p className="text-2xl font-bold">{totalReferrals}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <div className="ml-2">
                <p className="text-sm font-medium text-gray-600">Active Students</p>
                <p className="text-2xl font-bold">{activeReferrals}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <DollarSign className="h-4 w-4 text-yellow-600" />
              <div className="ml-2">
                <p className="text-sm font-medium text-gray-600">Total Commissions</p>
                <p className="text-2xl font-bold">${totalCommissions.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <DollarSign className="h-4 w-4 text-orange-600" />
              <div className="ml-2">
                <p className="text-sm font-medium text-gray-600">Pending Payouts</p>
                <p className="text-2xl font-bold">${pendingPayouts.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="links" className="space-y-6">
        <TabsList>
          <TabsTrigger value="links">Referral Links</TabsTrigger>
          <TabsTrigger value="referrals">My Referrals</TabsTrigger>
          <TabsTrigger value="payouts">Payouts</TabsTrigger>
        </TabsList>

        <TabsContent value="links" className="space-y-6">
          {/* Create New Link */}
          <Card>
            <CardHeader>
              <CardTitle>Create New Referral Link</CardTitle>
              <CardDescription>
                Generate a unique referral link to track your referrals
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label htmlFor="campaign-name">Campaign Name</Label>
                  <Input
                    id="campaign-name"
                    placeholder="e.g., Social Media Campaign, Newsletter"
                    value={newLinkName}
                    onChange={(e) => setNewLinkName(e.target.value)}
                  />
                </div>
                <div className="flex items-end">
                  <Button 
                    onClick={() => createLinkMutation.mutate(newLinkName)}
                    disabled={!newLinkName.trim() || createLinkMutation.isPending}
                  >
                    <LinkIcon className="h-4 w-4 mr-2" />
                    Create Link
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Existing Links */}
          <Card>
            <CardHeader>
              <CardTitle>Your Referral Links</CardTitle>
              <CardDescription>
                Manage and share your referral links
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {referralLinks.map((link) => {
                  const referralUrl = generateReferralUrl(link.linkId);
                  const linkReferrals = referrals.filter(r => r.linkId === link.id);
                  
                  return (
                    <div key={link.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h3 className="font-medium">{link.campaignName}</h3>
                          <p className="text-sm text-gray-500">
                            Created {new Date(link.createdAt || '').toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={link.isActive ? "default" : "secondary"}>
                          {link.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                      
                      <div className="bg-gray-50 rounded p-3 mb-3">
                        <div className="flex items-center justify-between">
                          <code className="text-sm text-gray-700 break-all">
                            {referralUrl}
                          </code>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(referralUrl)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Referrals:</span>
                          <span className="ml-1 font-medium">{linkReferrals.length}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Active:</span>
                          <span className="ml-1 font-medium">
                            {linkReferrals.filter(r => r.status === 'active').length}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">Commissions:</span>
                          <span className="ml-1 font-medium">
                            ${linkReferrals.reduce((sum, r) => sum + parseFloat(r.commissionAmount || '0'), 0).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {referralLinks.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <LinkIcon className="h-8 w-8 mx-auto mb-2" />
                    <p>No referral links created yet.</p>
                    <p className="text-sm">Create your first referral link above to start earning commissions.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrals" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Referrals</CardTitle>
              <CardDescription>
                Track all students referred through your links
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {referrals.map((referral) => (
                  <div key={referral.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h3 className="font-medium">{referral.studentName}</h3>
                        <p className="text-sm text-gray-500">{referral.studentEmail}</p>
                      </div>
                      <Badge variant={
                        referral.status === 'completed' ? 'default' :
                        referral.status === 'active' ? 'secondary' :
                        'outline'
                      }>
                        {referral.status}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">Course:</span>
                        <p className="font-medium">{referral.courseSelected}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Original Price:</span>
                        <p className="font-medium">${referral.originalPrice}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Final Price:</span>
                        <p className="font-medium">${referral.finalPrice}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Your Commission:</span>
                        <p className="font-medium text-green-600">${referral.commissionAmount}</p>
                      </div>
                    </div>

                    <div className="mt-3 text-xs text-gray-500">
                      Referred on {new Date(referral.createdAt || '').toLocaleDateString()}
                    </div>
                  </div>
                ))}

                {referrals.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="h-8 w-8 mx-auto mb-2" />
                    <p>No referrals yet.</p>
                    <p className="text-sm">Share your referral links to start earning commissions.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payouts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Payout History</CardTitle>
              <CardDescription>
                Track your commission payouts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {payouts.map((payout) => (
                  <div key={payout.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">${payout.amount}</h3>
                        <p className="text-sm text-gray-500">
                          {new Date(payout.createdAt || '').toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant={
                        payout.status === 'paid' ? 'default' :
                        payout.status === 'pending' ? 'secondary' :
                        'outline'
                      }>
                        {payout.status}
                      </Badge>
                    </div>
                  </div>
                ))}

                {payouts.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <DollarSign className="h-8 w-8 mx-auto mb-2" />
                    <p>No payouts yet.</p>
                    <p className="text-sm">Complete referrals to start earning commissions.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}