import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Club, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Register() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    certification: "",
  });
  const { toast } = useToast();

  const registerMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/coaches/register", data);
      return response.json();
    },
    onSuccess: (coach) => {
      toast({
        title: "Registration successful!",
        description: `Welcome ${coach.name}! Your Coach ID is ${coach.coachId}`,
      });
      setLocation("/dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Registration failed",
        description: error.message || "Please check your information and try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.password || !formData.certification) {
      toast({
        title: "All fields required",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    registerMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Club className="text-primary text-3xl" />
            <span className="text-2xl font-bold text-primary">Red2Blue Coaching</span>
          </div>
          <h2 className="mt-6 text-3xl font-bold text-foreground">
            Join Our Coach Network
          </h2>
          <p className="mt-2 text-sm text-neutral">
            Register as an EGF/UAE PGA Professional and start earning referral commissions
          </p>
        </div>

        {/* Registration Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <UserPlus className="w-5 h-5" />
              <span>Coach Registration</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  required
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  placeholder="Create a secure password"
                />
              </div>

              <div>
                <Label htmlFor="certification">Professional Certification *</Label>
                <Select value={formData.certification} onValueChange={(value) => handleInputChange("certification", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your certification" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PGA-UAE">PGA UAE Professional</SelectItem>
                    <SelectItem value="EGF">EGF Professional</SelectItem>
                    <SelectItem value="PGA-UK">PGA UK Professional</SelectItem>
                    <SelectItem value="PGA-US">PGA US Professional</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-blue-50 rounded-lg p-4">
                <h4 className="font-semibold text-primary mb-2">What you'll get:</h4>
                <ul className="text-sm text-foreground space-y-1">
                  <li>• Unique Coach ID for tracking referrals</li>
                  <li>• 15% commission on all successful referrals</li>
                  <li>• Personalized referral link generator</li>
                  <li>• Real-time analytics dashboard</li>
                  <li>• Monthly payout processing</li>
                </ul>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? "Creating Account..." : "Register as Coach"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-neutral">
                Already have an account?{" "}
                <Link href="/dashboard" className="text-primary hover:text-blue-700 font-medium">
                  Sign in to dashboard
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Additional Info */}
        <div className="text-center">
          <p className="text-xs text-neutral">
            By registering, you agree to our Terms of Service and Privacy Policy.
            Your professional certification will be verified before account approval.
          </p>
        </div>
      </div>
    </div>
  );
}
