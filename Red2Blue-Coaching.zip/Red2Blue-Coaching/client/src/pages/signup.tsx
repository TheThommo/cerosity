import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Target, Star } from "lucide-react";

export default function Signup() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Extract referral code from URL
  const urlParams = new URLSearchParams(window.location.search);
  const referralCode = urlParams.get('ref');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    dateOfBirth: '',
    golfExperience: 'beginner',
  });

  const [referralInfo, setReferralInfo] = useState<{
    coachName: string;
    discount: number;
    originalPrice: number;
    finalPrice: number;
  } | null>(null);

  // Validate referral code when component loads
  useEffect(() => {
    if (referralCode) {
      validateReferralCode(referralCode);
    }
  }, [referralCode]);

  const validateReferralCode = async (code: string) => {
    try {
      const response = await apiRequest(`/api/referral-links/${code}`, 'GET') as any;
      if (response.coach) {
        const originalPrice = 299; // Red2Blue Athlete course price
        const discount = 20; // 20% discount for referrals
        const finalPrice = originalPrice * (1 - discount / 100);
        
        setReferralInfo({
          coachName: response.coach.name,
          discount,
          originalPrice,
          finalPrice
        });
      }
    } catch (error) {
      console.error('Invalid referral code:', error);
    }
  };

  const signupMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const payload = {
        ...data,
        referralCode: referralCode || undefined,
        courseSelected: 'red2blue-athlete',
        discountApplied: referralInfo?.discount || 0
      };
      return await apiRequest('/api/auth/student/signup', 'POST', payload);
    },
    onSuccess: () => {
      toast({
        title: "Account Created Successfully!",
        description: referralInfo 
          ? `Welcome! Your ${referralInfo.discount}% discount has been applied.`
          : "Welcome to Red2Blue Coaching!",
      });
      setLocation('/login');
    },
    onError: (error: any) => {
      toast({
        title: "Signup Failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    signupMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <Target className="h-8 w-8 text-green-600 mr-2" />
            <h1 className="text-2xl font-bold text-gray-900">Red2Blue Coaching</h1>
          </div>
          <p className="text-gray-600">Join the premier golf coaching program</p>
        </div>

        {/* Referral Discount Banner */}
        {referralInfo && (
          <Card className="border-green-200 bg-green-50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  <div>
                    <p className="font-medium text-green-800">
                      Referral Discount Applied!
                    </p>
                    <p className="text-sm text-green-600">
                      Referred by coach {referralInfo.coachName}
                    </p>
                  </div>
                </div>
                <Badge className="bg-green-600">
                  {referralInfo.discount}% OFF
                </Badge>
              </div>
              
              <div className="mt-4 p-3 bg-white rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Original Price:</span>
                  <span className="line-through text-gray-500">${referralInfo.originalPrice}</span>
                </div>
                <div className="flex justify-between items-center font-bold text-green-600">
                  <span>Your Price:</span>
                  <span>${referralInfo.finalPrice}</span>
                </div>
                <div className="text-center mt-2 text-sm text-green-600">
                  You save ${referralInfo.originalPrice - referralInfo.finalPrice}!
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Course Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Star className="h-5 w-5 text-yellow-500 mr-2" />
              Red2Blue Athlete Course
            </CardTitle>
            <CardDescription>
              Complete 4-session golf fundamentals program designed for athletes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Duration:</span>
                <p className="font-medium">4 Sessions</p>
              </div>
              <div>
                <span className="text-gray-600">Level:</span>
                <p className="font-medium">All Levels</p>
              </div>
              <div>
                <span className="text-gray-600">Format:</span>
                <p className="font-medium">One-on-One</p>
              </div>
              <div>
                <span className="text-gray-600">Certification:</span>
                <p className="font-medium">PGA Certified</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Signup Form */}
        <Card>
          <CardHeader>
            <CardTitle>Create Your Account</CardTitle>
            <CardDescription>
              Fill in your details to get started with Red2Blue Coaching
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="golfExperience">Golf Experience</Label>
                  <Select 
                    value={formData.golfExperience} 
                    onValueChange={(value) => handleInputChange('golfExperience', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {referralCode && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <p className="text-sm text-blue-600">
                    <strong>Referral Code:</strong> {referralCode}
                  </p>
                </div>
              )}

              <Button 
                type="submit" 
                className="w-full" 
                disabled={signupMutation.isPending}
              >
                {signupMutation.isPending ? 'Creating Account...' : 'Create Account & Enroll'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Login Link */}
        <div className="text-center">
          <p className="text-sm text-gray-600">
            Already have an account?{' '}
            <Button 
              variant="link" 
              className="p-0 h-auto text-blue-600"
              onClick={() => setLocation('/login')}
            >
              Sign in here
            </Button>
          </p>
        </div>
      </div>
    </div>
  );
}