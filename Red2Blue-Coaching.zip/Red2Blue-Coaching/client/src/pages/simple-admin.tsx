import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Users, GraduationCap, BookOpen } from "lucide-react";
import NavigationHeader from "@/components/navigation-header";

interface AdminStats {
  totalCoaches: number;
  totalStudents: number;
  totalEnrollments: number;
  completedCourses: number;
  totalRevenue: number;
}

type ViewState = 'dashboard' | 'coaches' | 'coach-details' | 'students' | 'student-details';

export default function SimpleAdmin() {
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  const [selectedCoachId, setSelectedCoachId] = useState<number | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);

  const { data: stats } = useQuery<AdminStats>({
    queryKey: ['/api/admin/stats'],
  });

  const { data: coaches = [] } = useQuery<any[]>({
    queryKey: ['/api/coaches'],
    enabled: currentView === 'coaches' || currentView === 'coach-details',
  });

  const { data: students = [] } = useQuery<any[]>({
    queryKey: ['/api/students'],
    enabled: currentView === 'students' || currentView === 'student-details',
  });

  const { data: enrollments = [] } = useQuery<any[]>({
    queryKey: ['/api/enrollments'],
    enabled: currentView === 'coach-details' || currentView === 'student-details',
  });

  const { data: courses = [] } = useQuery<any[]>({
    queryKey: ['/api/courses'],
    enabled: currentView === 'student-details',
  });

  const selectedCoach = (coaches as any[]).find((c: any) => c.id === selectedCoachId);
  const selectedStudent = (students as any[]).find((s: any) => s.id === selectedStudentId);
  const coachEnrollments = (enrollments as any[]).filter((e: any) => e.coachId === selectedCoachId);
  const studentEnrollments = (enrollments as any[]).filter((e: any) => e.studentId === selectedStudentId);

  const renderDashboard = () => (
    <div className="space-y-6">
      <NavigationHeader 
        title="Admin Dashboard"
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-gray-600 mb-6">Red2Blue Coaching Management System</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-blue-200"
          onClick={() => setCurrentView('coaches')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Coaches</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats?.totalCoaches || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Click to view coach list and details
            </p>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-green-200"
          onClick={() => setCurrentView('students')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <GraduationCap className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats?.totalStudents || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Click to view student list and progress
            </p>
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );

  const renderCoachesList = () => (
    <div className="space-y-6">
      <NavigationHeader 
        title="Coaches"
        breadcrumbs={[{ label: "Coaches" }]}
        showBack={true}
        backPath="/"
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

      <div className="grid gap-4">
        {(coaches as any[]).map((coach: any) => (
          <Card 
            key={coach.id}
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => {
              setSelectedCoachId(coach.id);
              setCurrentView('coach-details');
            }}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-semibold">{coach.name}</h3>
                  <p className="text-sm text-gray-600">ID: {coach.coachId}</p>
                  <p className="text-sm text-gray-600">{coach.email}</p>
                </div>
                <div className="text-right">
                  <Badge variant={coach.status === 'active' ? 'default' : 'secondary'}>
                    {coach.status}
                  </Badge>
                  <p className="text-sm text-gray-500 mt-2">
                    Click for details
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      </div>
    </div>
  );

  const renderCoachDetails = () => (
    <div className="space-y-6">
      <NavigationHeader 
        title="Coach Details"
        breadcrumbs={[
          { label: "Coaches", path: "#" },
          { label: selectedCoach?.name || "Coach Details" }
        ]}
        showBack={true}
        backPath="#"
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

      {selectedCoach && (
        <Card>
          <CardHeader>
            <CardTitle>{selectedCoach.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Coach ID</label>
                <p className="text-sm">{selectedCoach.coachId}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Email</label>
                <p className="text-sm">{selectedCoach.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Phone</label>
                <p className="text-sm">{selectedCoach.phone}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Status</label>
                <Badge variant={selectedCoach.status === 'active' ? 'default' : 'secondary'}>
                  {selectedCoach.status}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Students Signed Up by This Coach - Permanent Relationships */}
      <Card>
        <CardHeader>
          <CardTitle>Students Signed Up by This Coach (Permanent Attachments)</CardTitle>
        </CardHeader>
        <CardContent>
          {(() => {
            const permanentStudents = (students as any[]).filter((s: any) => s.coachId === selectedCoachId);
            return permanentStudents.length > 0 ? (
              <div className="space-y-3">
                {permanentStudents.map((student: any) => (
                  <div key={student.id} className="p-3 border rounded bg-blue-50 border-blue-200">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-blue-900">{student.name}</p>
                        <p className="text-sm text-blue-700">Student ID: {student.studentId}</p>
                        <p className="text-sm text-blue-600">{student.email}</p>
                        <p className="text-xs text-blue-500 mt-1">
                          Enrolled: {new Date(student.enrollmentDate || student.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                        {student.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No students have been signed up by this coach yet</p>
            );
          })()}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Current Course Enrollments</CardTitle>
        </CardHeader>
        <CardContent>
          {coachEnrollments?.length > 0 ? (
            <div className="space-y-3">
              {coachEnrollments.map((enrollment: any) => {
                const student = (students as any[]).find((s: any) => s.id === enrollment.studentId);
                return (
                  <div key={enrollment.id} className="flex justify-between items-center p-3 border rounded">
                    <div>
                      <p className="font-medium">{student?.name}</p>
                      <p className="text-sm text-gray-600">Student ID: {student?.studentId}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant={enrollment.status === 'active' ? 'default' : 'secondary'}>
                        {enrollment.status}
                      </Badge>
                      <p className="text-sm text-gray-500">Progress: {enrollment.progress}%</p>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-500">No current course enrollments found</p>
          )}
        </CardContent>
      </Card>
      </div>
    </div>
  );

  const renderStudentsList = () => (
    <div className="space-y-6">
      <NavigationHeader 
        title="Students"
        breadcrumbs={[{ label: "Students" }]}
        showBack={true}
        backPath="/"
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

      <div className="grid gap-4">
        {(students as any[]).map((student: any) => {
          const signupCoach = (coaches as any[]).find((c: any) => c.id === student.coachId);
          return (
            <Card 
              key={student.id}
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => {
                setSelectedStudentId(student.id);
                setCurrentView('student-details');
              }}
            >
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold">{student.name}</h3>
                    <p className="text-sm text-gray-600">ID: {student.studentId}</p>
                    <p className="text-sm text-gray-600">{student.email}</p>
                    <div className="mt-1">
                      {student.referralSource === 'red2blue_direct' ? (
                        <div className="space-y-1">
                          <p className="text-sm text-green-600 font-medium">
                            Red2Blue Direct Marketing
                          </p>
                          <p className="text-xs text-green-500">
                            10% Discount Applied
                          </p>
                        </div>
                      ) : signupCoach ? (
                        <div className="space-y-1">
                          <p className="text-sm text-blue-600 font-medium">
                            Signed up by: {signupCoach.name}
                          </p>
                          {student.discountApplied > 0 && (
                            <p className="text-xs text-blue-500">
                              {student.discountApplied}% Discount Applied
                            </p>
                          )}
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500 font-medium">
                          Direct Registration
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                      {student.status}
                    </Badge>
                    <p className="text-sm text-gray-500 mt-2">
                      Click for details
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );

  const renderStudentDetails = () => (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="outline" onClick={() => setCurrentView('students')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Students
        </Button>
        <h1 className="text-3xl font-bold text-gray-900">Student Details</h1>
      </div>

      {selectedStudent && (
        <Card>
          <CardHeader>
            <CardTitle>{selectedStudent.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Student ID</label>
                <p className="text-sm">{selectedStudent.studentId}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Email</label>
                <p className="text-sm">{selectedStudent.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Phone</label>
                <p className="text-sm">{selectedStudent.phone}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Status</label>
                <Badge variant={selectedStudent.status === 'active' ? 'default' : 'secondary'}>
                  {selectedStudent.status}
                </Badge>
              </div>
            </div>
            
            {/* Referral Source and Discount Information */}
            <div className="mt-6 space-y-4">
              {selectedStudent.referralSource === 'red2blue_direct' ? (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h4 className="font-semibold text-green-900 mb-2">Red2Blue Direct Marketing Referral</h4>
                  <div className="space-y-2">
                    <p className="font-medium text-green-800">Marketing Campaign Registration</p>
                    <p className="text-sm text-green-600">Source: Red2Blue Direct Marketing</p>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        {selectedStudent.discountApplied}% Discount Applied
                      </Badge>
                    </div>
                    <p className="text-xs text-green-600 mt-2">
                      This student registered through Red2Blue's direct marketing campaign and received an automatic 10% discount.
                    </p>
                  </div>
                </div>
              ) : selectedStudent.coachId ? (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">Coach Referral (Permanent Attachment)</h4>
                  {(() => {
                    const signupCoach = (coaches as any[]).find((c: any) => c.id === selectedStudent.coachId);
                    return signupCoach ? (
                      <div className="space-y-2">
                        <p className="font-medium text-blue-800">{signupCoach.name}</p>
                        <p className="text-sm text-blue-600">Coach ID: {signupCoach.coachId}</p>
                        <p className="text-sm text-blue-600">Email: {signupCoach.email}</p>
                        {selectedStudent.discountApplied > 0 && (
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                            {selectedStudent.discountApplied}% Discount Applied
                          </Badge>
                        )}
                        <p className="text-xs text-blue-500 mt-1">
                          This student was originally referred by this coach and they maintain a permanent relationship.
                        </p>
                      </div>
                    ) : (
                      <p className="text-blue-600">Coach information loading...</p>
                    );
                  })()}
                </div>
              ) : (
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Direct Registration</h4>
                  <p className="text-gray-600">This student registered directly without a referral.</p>
                  {selectedStudent.discountApplied > 0 && (
                    <Badge variant="secondary" className="bg-gray-100 text-gray-800 mt-2">
                      {selectedStudent.discountApplied}% Discount Applied
                    </Badge>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Course Progress & Coach Association</CardTitle>
        </CardHeader>
        <CardContent>
          {studentEnrollments?.length > 0 ? (
            <div className="space-y-3">
              {studentEnrollments.map((enrollment: any) => {
                const coach = (coaches as any[]).find((c: any) => c.id === enrollment.coachId);
                const course = (courses as any[]).find((c: any) => c.id === enrollment.courseId);
                return (
                  <div key={enrollment.id} className="p-4 border rounded space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium flex items-center">
                          <BookOpen className="h-4 w-4 mr-2" />
                          {course?.name}
                        </h4>
                        <p className="text-sm text-gray-600">Course ID: {course?.courseId}</p>
                      </div>
                      <Badge variant={enrollment.status === 'active' ? 'default' : 'secondary'}>
                        {enrollment.status}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-medium">Coach: {coach?.name}</p>
                        <p className="text-xs text-gray-500">ID: {coach?.coachId}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">Progress: {enrollment.progress}%</p>
                        <div className="w-24 bg-gray-200 rounded-full h-2 mt-1">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${enrollment.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-500">No course enrollments found</p>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return renderDashboard();
      case 'coaches':
        return renderCoachesList();
      case 'coach-details':
        return renderCoachDetails();
      case 'students':
        return renderStudentsList();
      case 'student-details':
        return renderStudentDetails();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderCurrentView()}
      </div>
    </div>
  );
}