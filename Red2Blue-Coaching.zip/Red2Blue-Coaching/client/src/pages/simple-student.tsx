import { useAuth } from "@/hooks/useAuth";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import type { CheckedState } from "@radix-ui/react-checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Circle, Trophy, Calendar } from "lucide-react";
import NavigationHeader from "@/components/navigation-header";

export default function SimpleStudent() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Track session completion status locally for this referral tracking system
  const [completedSessions, setCompletedSessions] = useState<Set<number>>(new Set());

  const sessions = [
    { id: 1, sessionNumber: 1 },
    { id: 2, sessionNumber: 2 },
    { id: 3, sessionNumber: 3 },
    { id: 4, sessionNumber: 4 },
  ];

  const courseData = {
    name: "Red2Blue Athlete Course",
    description: "Complete golf training program",
    totalSessions: sessions.length
  };

  // Notify coach when course is completed
  const notifyCoachMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/attendance', 'POST', {
        studentId: user?.id,
        sessionDate: new Date().toISOString(),
        status: 'course_completed',
        notes: `Red2Blue Athlete course completed on ${new Date().toLocaleDateString()}`
      });
    },
    onSuccess: () => {
      toast({
        title: "Course Completed!",
        description: "Your coach has been notified of your completion.",
      });
    }
  });

  const handleSessionToggle = (sessionId: number, completed: boolean) => {
    setCompletedSessions(prev => {
      const newSet = new Set(prev);
      if (completed) {
        newSet.add(sessionId);
        toast({
          title: "Session Completed",
          description: `Session ${sessionId} marked as completed!`,
        });
      } else {
        newSet.delete(sessionId);
      }
      return newSet;
    });
  };

  // Check if course is completed and notify coach
  useEffect(() => {
    const numCompleted = completedSessions.size;
    if (numCompleted === 4 && numCompleted > 0) {
      notifyCoachMutation.mutate();
    }
  }, [completedSessions]);

  const numCompletedSessions = completedSessions.size;
  const progressPercentage = sessions.length > 0 ? (numCompletedSessions / sessions.length) * 100 : 0;
  const isCompleted = numCompletedSessions === sessions.length && sessions.length > 0;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <NavigationHeader 
        title="My Course Progress"
        breadcrumbs={[
          { label: "Dashboard", path: "/" },
          { label: "Course Progress" }
        ]}
      />

      {/* Course Overview */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                {isCompleted ? (
                  <Trophy className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Circle className="h-5 w-5 text-blue-500" />
                )}
                {courseData.name}
              </CardTitle>
              <CardDescription>
                Track your session completion progress
              </CardDescription>
            </div>
            <Badge variant={isCompleted ? "default" : "secondary"}>
              {isCompleted ? "Completed" : "In Progress"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Progress</span>
                <span>{numCompletedSessions} of {sessions.length} sessions</span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </div>
            
            {isCompleted && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-medium">Congratulations!</span>
                </div>
                <p className="text-green-600 text-sm mt-1">
                  You have completed all sessions in the Red2Blue Athlete course.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Session Checklist */}
      <Card>
        <CardHeader>
          <CardTitle>Session Checklist</CardTitle>
          <CardDescription>
            Mark each session as completed when you finish
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {sessions.map((session) => {
              const isSessionCompleted = completedSessions.has(session.id);
              
              return (
                <div key={session.id} className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                  <Checkbox
                    checked={isSessionCompleted}
                    onCheckedChange={(checked: CheckedState) => {
                      handleSessionToggle(session.id, checked === true);
                    }}
                    className="h-5 w-5"
                  />
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className={`font-medium ${isSessionCompleted ? 'text-green-700' : 'text-gray-900'}`}>
                        Session {session.sessionNumber}
                      </span>
                      {isSessionCompleted && <CheckCircle className="h-4 w-4 text-green-500" />}
                    </div>
                    
                    <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        <span>
                          {isSessionCompleted 
                            ? "Completed" 
                            : "Pending completion"
                          }
                        </span>
                      </div>
                    </div>
                  </div>

                  <Badge variant={isSessionCompleted ? "default" : "outline"}>
                    {isSessionCompleted ? "Completed" : "Pending"}
                  </Badge>
                </div>
              );
            })}

            {sessions.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Circle className="h-8 w-8 mx-auto mb-2" />
                <p>No sessions found for your course.</p>
                <p className="text-sm">Contact your coach if you believe this is an error.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      {!isCompleted && sessions.length > 0 && (
        <Card className="mt-6">
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="font-medium text-gray-900 mb-2">Need Help?</h3>
              <p className="text-sm text-gray-600 mb-4">
                Contact your coach if you have questions about any session or need assistance.
              </p>
              <Button variant="outline" size="sm">
                Contact Coach
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}