import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Calendar, BookOpen, Clock, CheckCircle, Star, Award, TrendingUp } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/navigation";
import StatsCard from "@/components/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";
import type { Student, Coach, Enrollment, Session } from "@shared/schema";

export default function StudentDashboard() {
  const { user, isStudent } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [feedbackText, setFeedbackText] = useState("");
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);
  const { toast } = useToast();

  const { data: student } = useQuery<Student>({
    queryKey: [`/api/students/${user?.id}`],
    enabled: isStudent && !!user?.id,
  });

  const { data: coach } = useQuery<Coach>({
    queryKey: [`/api/coaches/${student?.coachId}`],
    enabled: isStudent && !!student?.coachId,
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: [`/api/students/${user?.id}/enrollments`],
    enabled: isStudent && !!user?.id,
  });

  const { data: allSessions = [] } = useQuery<Session[]>({
    queryKey: ["/api/sessions"],
    enabled: isStudent && enrollments.length > 0,
  });

  if (!isStudent) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-6 text-center">
            <h1 className="text-xl font-bold text-destructive mb-2">Access Denied</h1>
            <p className="text-neutral">You need student privileges to access this dashboard.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-success/10 text-success";
      case "scheduled":
        return "bg-blue-100 text-blue-800";
      case "missed":
        return "bg-red-100 text-red-800";
      case "cancelled":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-yellow-100 text-yellow-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4" />;
      case "scheduled":
        return <Clock className="w-4 h-4" />;
      default:
        return <Calendar className="w-4 h-4" />;
    }
  };

  // Filter sessions for this student's enrollments
  const studentSessions = allSessions.filter(session =>
    enrollments.some(enrollment => enrollment.id === session.enrollmentId)
  );

  const todaysSessions = studentSessions.filter(session => {
    if (!selectedDate) return false;
    const sessionDate = new Date(session.scheduledDate);
    return sessionDate.toDateString() === selectedDate.toDateString();
  });

  const upcomingSessions = studentSessions.filter(session => {
    const sessionDate = new Date(session.scheduledDate);
    const today = new Date();
    return sessionDate > today;
  }).slice(0, 5);

  const completedSessions = studentSessions.filter(s => s.status === "completed");
  const totalSessions = studentSessions.length;
  const attendanceRate = totalSessions > 0 ? (completedSessions.length / totalSessions) * 100 : 0;

  const averageRating = completedSessions.reduce((sum, session) => 
    sum + (session.rating || 0), 0) / Math.max(completedSessions.length, 1);

  const activeEnrollments = enrollments.filter(e => e.status === 'in_progress');
  const completedEnrollments = enrollments.filter(e => e.status === 'completed');

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-4 mb-4">
            <Avatar className="w-16 h-16">
              <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${student?.name}`} />
              <AvatarFallback className="text-xl">
                {student?.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Welcome, {student?.name}</h1>
              <p className="text-neutral">Student ID: {student?.studentId}</p>
              {coach && (
                <p className="text-sm text-neutral">
                  Coached by <span className="font-medium text-foreground">{coach.name}</span> ({coach.certification})
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Course Progress"
            value={`${activeEnrollments.length} Active`}
            change={`${completedEnrollments.length} completed`}
            changeLabel="total courses"
            icon={BookOpen}
            iconColor="text-primary"
            iconBgColor="bg-primary/10"
          />
          <StatsCard
            title="Attendance Rate"
            value={`${Math.round(attendanceRate)}%`}
            change={`${completedSessions.length}/${totalSessions}`}
            changeLabel="sessions attended"
            icon={CheckCircle}
            iconColor="text-success"
            iconBgColor="bg-success/10"
          />
          <StatsCard
            title="Session Rating"
            value={averageRating.toFixed(1)}
            change="⭐ Average rating"
            changeLabel="from coach feedback"
            icon={Star}
            iconColor="text-yellow-600"
            iconBgColor="bg-yellow-100"
          />
          <StatsCard
            title="Learning Streak"
            value="12 days"
            change="New record!"
            changeLabel="consecutive learning"
            icon={TrendingUp}
            iconColor="text-secondary"
            iconBgColor="bg-secondary/10"
          />
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Course Progress & Attendance */}
          <div className="lg:col-span-2 space-y-6">
            {/* Course Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BookOpen className="w-5 h-5" />
                  <span>My Courses</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {enrollments.map((enrollment) => (
                    <div key={enrollment.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-semibold">Course #{enrollment.courseId}</h4>
                          <p className="text-sm text-neutral">
                            Started: {formatDate(enrollment.startDate)}
                          </p>
                        </div>
                        <Badge className={getStatusColor(enrollment.status)} variant="secondary">
                          {enrollment.status}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">{enrollment.progress || 0}%</span>
                        </div>
                        <Progress value={enrollment.progress || 0} className="h-2" />
                      </div>

                      {enrollment.finalGrade && (
                        <div className="mt-3 flex items-center space-x-2">
                          <Award className="w-4 h-4 text-yellow-600" />
                          <span className="text-sm font-medium">Final Grade: {enrollment.finalGrade}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Attendance Records */}
            <Card>
              <CardHeader>
                <CardTitle>Session Attendance Records</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Session</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Coach Notes</TableHead>
                        <TableHead>My Rating</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {studentSessions.slice(0, 10).map((session) => (
                        <TableRow key={session.id}>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              {getStatusIcon(session.status)}
                              <span className="font-medium">Session #{session.sessionNumber}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {formatDate(session.scheduledDate)}
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(session.status)} variant="secondary">
                              {session.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm max-w-xs">
                            {session.coachFeedback ? (
                              <div className="truncate" title={session.coachFeedback}>
                                {session.coachFeedback}
                              </div>
                            ) : (
                              <span className="text-neutral">No notes yet</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {session.rating ? (
                              <div className="flex items-center space-x-1">
                                <span className="text-sm font-medium">{session.rating}</span>
                                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              </div>
                            ) : (
                              <span className="text-neutral text-sm">Not rated</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {session.status === "completed" && !session.studentFeedback && (
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setSelectedSession(session)}
                              >
                                Add Feedback
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Calendar & Upcoming Sessions */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5" />
                  <span>Session Calendar</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CalendarComponent
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                />
                
                {selectedDate && (
                  <div className="mt-6">
                    <h4 className="font-semibold mb-3">
                      Sessions on {formatDate(selectedDate)}
                    </h4>
                    {todaysSessions.length > 0 ? (
                      <div className="space-y-2">
                        {todaysSessions.map((session) => (
                          <div key={session.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div className="text-sm">
                              <div className="font-medium">Session #{session.sessionNumber}</div>
                              <div className="text-neutral">
                                {new Date(session.scheduledDate).toLocaleTimeString()}
                              </div>
                            </div>
                            <Badge className={getStatusColor(session.status)} variant="secondary">
                              {session.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-neutral">No sessions today</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upcoming Sessions</CardTitle>
              </CardHeader>
              <CardContent>
                {upcomingSessions.length > 0 ? (
                  <div className="space-y-3">
                    {upcomingSessions.map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 border border-gray-200 rounded">
                        <div>
                          <div className="font-medium text-sm">Session #{session.sessionNumber}</div>
                          <div className="text-neutral text-xs">
                            {formatDate(session.scheduledDate)}
                          </div>
                        </div>
                        <Badge className={getStatusColor(session.status)} variant="secondary">
                          {session.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-neutral">No upcoming sessions</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>My Learning Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-sm">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-success" />
                    <span>Master basic swing mechanics</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-success" />
                    <span>Improve putting accuracy</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="w-4 h-4 text-yellow-600" />
                    <span>Lower handicap to 15</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="w-4 h-4 text-neutral" />
                    <span>Complete short game course</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {coach && (
              <Card>
                <CardHeader>
                  <CardTitle>My Coach</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${coach.name}`} />
                      <AvatarFallback>
                        {coach.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{coach.name}</div>
                      <div className="text-sm text-neutral">{coach.certification}</div>
                      <div className="text-xs text-neutral">{coach.email}</div>
                    </div>
                  </div>
                  {coach.bio && (
                    <p className="text-sm text-neutral">{coach.bio}</p>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Feedback Modal */}
        {selectedSession && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="w-full max-w-md mx-4">
              <CardHeader>
                <CardTitle>Session Feedback</CardTitle>
                <p className="text-sm text-neutral">
                  How was Session #{selectedSession.sessionNumber}?
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="feedback">Your feedback</Label>
                  <Textarea
                    id="feedback"
                    placeholder="Share your thoughts about this session..."
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setSelectedSession(null);
                      setFeedbackText("");
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      toast({
                        title: "Feedback submitted",
                        description: "Thank you for your feedback!",
                      });
                      setSelectedSession(null);
                      setFeedbackText("");
                    }}
                  >
                    Submit
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}