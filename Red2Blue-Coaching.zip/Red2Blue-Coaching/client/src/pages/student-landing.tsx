import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency } from "@/lib/utils";
import type { ReferralLink, Coach } from "@shared/schema";

export default function StudentLanding() {
  const { linkId } = useParams();
  const [location] = useLocation();
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const { toast } = useToast();

  // Parse URL parameters
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const discount = parseInt(urlParams.get('discount') || '10');

  const { data: linkData, isLoading: linkLoading } = useQuery({
    queryKey: [`/api/referral-links/${linkId}`],
    enabled: !!linkId,
  });

  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  const bookingMutation = useMutation({
    mutationFn: async (bookingData: any) => {
      const response = await apiRequest("POST", "/api/referrals", bookingData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking successful!",
        description: "Your golf coaching session has been booked. Check your email for confirmation.",
      });
    },
    onError: () => {
      toast({
        title: "Booking failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCourseSelect = (courseId: string) => {
    setSelectedCourse(courseId);
  };

  const handleBooking = () => {
    if (!selectedCourse || !linkData) {
      toast({
        title: "Course selection required",
        description: "Please select a course before proceeding.",
        variant: "destructive",
      });
      return;
    }

    const course = courses.find((c: any) => c.id === selectedCourse);
    const originalPrice = course.price;
    const discountAmount = originalPrice * (discount / 100);
    const finalPrice = originalPrice - discountAmount;

    // In a real app, you'd collect student information first
    const studentData = {
      studentName: "Demo Student",
      studentEmail: "student@example.com",
    };

    bookingMutation.mutate({
      coachId: linkData.coach.id,
      linkId: linkData.link.id,
      studentName: studentData.studentName,
      studentEmail: studentData.studentEmail,
      courseSelected: selectedCourse,
      originalPrice: originalPrice.toString(),
      discountAmount: discountAmount.toString(),
      finalPrice: finalPrice.toString(),
      status: "pending",
    });
  };

  if (linkLoading) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-neutral">Loading referral information...</p>
        </div>
      </div>
    );
  }

  if (!linkData) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-6 text-center">
            <h1 className="text-xl font-bold text-destructive mb-2">Invalid Referral Link</h1>
            <p className="text-neutral">This referral link is not valid or has expired.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { link, coach }: { link: ReferralLink; coach: Coach } = linkData;

  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card className="overflow-hidden shadow-lg">
          {/* Header */}
          <div className="bg-gradient-to-r from-primary to-blue-600 text-white p-8 text-center">
            <div className="mb-4">
              <Avatar className="w-20 h-20 mx-auto border-4 border-white">
                <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${coach.name}`} />
                <AvatarFallback className="text-2xl">{coach.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
            </div>
            <h1 className="text-3xl font-bold mb-2">You're Invited by Coach {coach.name}</h1>
            <p className="text-blue-100 text-lg">{coach.certification} Professional | 15+ Years Experience</p>
            <div className="bg-white/20 rounded-lg p-4 mt-6 inline-block">
              <p className="text-sm">Special Referral Discount Applied</p>
              <p className="text-2xl font-bold">{discount}% OFF</p>
            </div>
          </div>

          {/* Course Selection */}
          <CardContent className="p-8">
            <h3 className="text-xl font-semibold mb-6">Choose Your Golf Coaching Program</h3>
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {courses.map((course: any) => (
                <div
                  key={course.id}
                  className={`border border-gray-200 rounded-lg p-6 cursor-pointer transition-colors ${
                    selectedCourse === course.id ? 'border-primary bg-primary/5' : 'hover:border-primary'
                  }`}
                  onClick={() => handleCourseSelect(course.id)}
                >
                  <h4 className="font-semibold mb-2">{course.name}</h4>
                  <p className="text-neutral text-sm mb-4">{course.description}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-lg font-bold text-primary">
                        {formatCurrency(course.discountedPrice)}
                      </span>
                      <span className="text-sm text-neutral line-through ml-2">
                        {formatCurrency(course.price)}
                      </span>
                    </div>
                    <Badge className="bg-success/10 text-success">{discount}% OFF</Badge>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 bg-blue-50 rounded-lg mb-6">
              <div className="flex items-start space-x-4">
                <Info className="text-primary text-xl mt-1 w-5 h-5" />
                <div>
                  <h4 className="font-semibold text-primary mb-2">Your Special Benefits</h4>
                  <ul className="text-sm text-foreground space-y-1">
                    <li>• {discount}% automatic discount applied</li>
                    <li>• Priority booking with Coach {coach.name}</li>
                    <li>• Complimentary initial assessment</li>
                    <li>• Access to exclusive coaching materials</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="text-center">
              <Button
                size="lg"
                className="px-8 py-4 text-lg"
                onClick={handleBooking}
                disabled={!selectedCourse || bookingMutation.isPending}
              >
                {bookingMutation.isPending
                  ? "Processing..."
                  : "Claim Your Discount & Book Now"
                }
              </Button>
              <p className="text-sm text-neutral mt-2">Secure booking • Money-back guarantee</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
