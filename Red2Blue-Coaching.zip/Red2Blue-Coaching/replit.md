# Red2Blue Golf Coaching Referral Platform

## Overview

This is a full-stack golf coaching referral platform built for Red2Blue, enabling coaches to generate referral links, track student enrollments, and manage commission payouts. The application connects golf coaches with potential students through a structured referral system.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Authentication**: Session-based auth with HTTP-only cookies
- **API Design**: RESTful endpoints with role-based access control

## Key Components

### Database Schema
- **Users**: Separate tables for admins, coaches, and students with role-based authentication
- **Courses**: Golf course definitions (Red2Blue Athlete program)
- **Enrollments**: Student course registrations with progress tracking
- **Sessions**: Individual coaching sessions within courses
- **Referral System**: Links, referrals, and payout tracking
- **Attendance**: Session completion and coach notifications

### Authentication System
- Role-based access control (admin, coach, student)
- Session management with secure HTTP-only cookies
- Separate login endpoints for each user type
- Protected routes with middleware authentication

### Referral System
- Coaches can generate custom referral links with UTM tracking
- Students register through referral links with automatic discount application
- Commission tracking and payout management
- Direct Red2Blue registration with 10% discount

## Data Flow

1. **Coach Registration**: Coaches register and await admin approval
2. **Link Generation**: Approved coaches create referral links for campaigns
3. **Student Acquisition**: Students register through referral links or direct signup
4. **Course Enrollment**: Students enroll in Red2Blue Athlete course
5. **Progress Tracking**: Students mark session completion, coaches receive notifications
6. **Commission Processing**: System tracks referrals and calculates payouts

## External Dependencies

### Production Dependencies
- **Database**: Neon PostgreSQL serverless database
- **UI Components**: Radix UI primitives for accessibility
- **Form Management**: React Hook Form with Zod validation
- **Date Handling**: date-fns for date manipulation
- **Session Storage**: PostgreSQL-based session storage

### Development Tools
- **Type Safety**: TypeScript with strict configuration
- **Database Migrations**: Drizzle Kit for schema management
- **Development Server**: Concurrent frontend/backend development
- **Error Handling**: Runtime error overlay for development

## Deployment Strategy

### Build Process
- Frontend: Vite builds React app to `dist/public`
- Backend: esbuild bundles server code to `dist/index.js`
- Database: Drizzle handles schema migrations

### Environment Configuration
- Development: Local PostgreSQL or Neon database
- Production: Replit autoscale deployment
- Database URL required via environment variable
- Session-based authentication with secure cookies

## Changelog

```
Changelog:
- June 24, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Development Notes

- The application uses a monorepo structure with shared TypeScript schemas
- Database seeding is currently disabled for fresh data entry testing
- Three distinct user dashboards with role-specific functionality
- Mobile-responsive design with Tailwind CSS
- Real-time session completion tracking for coach notifications
- Commission calculation based on successful student course completions