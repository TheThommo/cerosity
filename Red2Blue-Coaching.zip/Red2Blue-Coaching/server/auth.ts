import { Request, Response, NextFunction } from "express";
import { storage } from "./storage";

export interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    email: string;
    role: 'admin' | 'coach' | 'student';
    name: string;
  };
}

// Simple session storage (in production, use Redis or database sessions)
const sessions = new Map<string, any>();

export function generateSessionId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

export async function loginAdmin(email: string, password: string) {
  try {
    const admin = await storage.getAdminByEmail(email);
    if (!admin || admin.password !== password) {
      return null;
    }
    
    const sessionId = generateSessionId();
    const sessionData = {
      id: admin.id,
      email: admin.email,
      role: 'admin' as const,
      name: admin.name,
    };
    
    sessions.set(sessionId, sessionData);
    return { sessionId, user: sessionData };
  } catch (error) {
    console.error('Admin login error:', error);
    return null;
  }
}

export async function loginCoach(email: string, password: string) {
  const coach = await storage.getCoachByEmail(email);
  if (!coach || coach.password !== password || coach.status !== 'approved') {
    return null;
  }
  
  const sessionId = generateSessionId();
  const sessionData = {
    id: coach.id,
    email: coach.email,
    role: 'coach' as const,
    name: coach.name,
  };
  
  sessions.set(sessionId, sessionData);
  return { sessionId, user: sessionData };
}

export async function loginStudent(email: string, password: string) {
  const student = await storage.getStudentByEmail(email);
  if (!student || student.password !== password || student.status !== 'active') {
    return null;
  }
  
  const sessionId = generateSessionId();
  const sessionData = {
    id: student.id,
    email: student.email,
    role: 'student' as const,
    name: student.name,
  };
  
  sessions.set(sessionId, sessionData);
  return { sessionId, user: sessionData };
}

export function logout(sessionId: string) {
  sessions.delete(sessionId);
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const sessionId = req.headers['authorization']?.replace('Bearer ', '') || req.cookies?.sessionId;
  
  if (!sessionId || !sessions.has(sessionId)) {
    return res.status(401).json({ message: 'Authentication required' });
  }
  
  req.user = sessions.get(sessionId);
  next();
}

export function requireRole(role: 'admin' | 'coach' | 'student') {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
}

export function requireRoles(roles: ('admin' | 'coach' | 'student')[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
}