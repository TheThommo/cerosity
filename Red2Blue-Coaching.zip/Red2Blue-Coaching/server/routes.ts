import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAdminSchema, insertStudentSchema, insertCoachSchema, insertCourseSchema, insertEnrollmentSchema, insertSessionSchema, insertReferralLinkSchema, insertReferralSchema } from "@shared/schema";
import { loginAdmin, loginCoach, loginStudent, logout, requireAuth, requireRole, requireRoles, type AuthenticatedRequest } from "./auth";
import cookieParser from "cookie-parser";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(cookieParser());

  // Authentication routes
  app.post("/api/auth/admin/login", async (req, res) => {
    const timeout = setTimeout(() => {
      if (!res.headersSent) {
        res.status(408).json({ message: "Request timeout" });
      }
    }, 10000); // 10 second timeout

    try {
      const { email, password } = req.body;
      const result = await Promise.race([
        loginAdmin(email, password),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error("Login timeout")), 8000)
        )
      ]);
      
      clearTimeout(timeout);
      
      if (!result) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      res.cookie('sessionId', result.sessionId, { httpOnly: true, secure: false });
      res.json({ user: result.user });
    } catch (error) {
      clearTimeout(timeout);
      console.error("Admin login error:", error);
      if (!res.headersSent) {
        res.status(500).json({ message: "Login failed", error: error.message });
      }
    }
  });

  app.post("/api/auth/coach/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const result = await loginCoach(email, password);
      if (!result) {
        return res.status(401).json({ message: "Invalid credentials or account not approved" });
      }
      res.cookie('sessionId', result.sessionId, { httpOnly: true, secure: false });
      res.json({ user: result.user });
    } catch (error) {
      res.status(500).json({ message: "Login failed", error });
    }
  });

  app.post("/api/auth/student/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const result = await loginStudent(email, password);
      if (!result) {
        return res.status(401).json({ message: "Invalid credentials or account inactive" });
      }
      res.cookie('sessionId', result.sessionId, { httpOnly: true, secure: false });
      res.json({ user: result.user });
    } catch (error) {
      res.status(500).json({ message: "Login failed", error });
    }
  });

  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    const sessionId = req.cookies?.sessionId;
    if (sessionId) {
      logout(sessionId);
      res.clearCookie('sessionId');
    }
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/me", requireAuth, async (req: AuthenticatedRequest, res) => {
    res.json({ user: req.user });
  });

  // Admin routes
  app.post("/api/admin/register", async (req, res) => {
    try {
      const adminData = insertAdminSchema.parse(req.body);
      const existingAdmin = await storage.getAdminByEmail(adminData.email);
      if (existingAdmin) {
        return res.status(400).json({ message: "Admin with this email already exists" });
      }
      const admin = await storage.createAdmin(adminData);
      res.status(201).json(admin);
    } catch (error) {
      res.status(400).json({ message: "Invalid admin data", error });
    }
  });

  app.get("/api/admin/stats", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch admin stats", error });
    }
  });

  // Student routes
  app.post("/api/students/register", async (req, res) => {
    try {
      const studentData = insertStudentSchema.parse(req.body);
      const existingStudent = await storage.getStudentByEmail(studentData.email);
      if (existingStudent) {
        return res.status(400).json({ message: "Student with this email already exists" });
      }
      const student = await storage.createStudent(studentData);
      res.status(201).json(student);
    } catch (error) {
      res.status(400).json({ message: "Invalid student data", error });
    }
  });

  // Red2Blue direct marketing registration with automatic 10% discount
  app.post("/api/students/register/red2blue", async (req, res) => {
    try {
      const studentData = insertStudentSchema.parse({
        ...req.body,
        referralSource: "red2blue_direct",
        discountApplied: 10,
        studentId: `STU-${Date.now()}`, // Generate unique student ID
      });
      
      const existingStudent = await storage.getStudentByEmail(studentData.email);
      if (existingStudent) {
        return res.status(400).json({ message: "Student with this email already exists" });
      }
      
      const student = await storage.createStudent(studentData);
      res.status(201).json({ 
        ...student, 
        message: "Registration successful with 10% discount applied!" 
      });
    } catch (error) {
      console.error("Red2Blue registration error:", error);
      res.status(400).json({ message: "Invalid student data", error });
    }
  });

  app.get("/api/students", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      let students;
      if (req.user?.role === 'admin') {
        students = await storage.getAllStudents();
      } else if (req.user?.role === 'coach') {
        students = await storage.getStudentsByCoachId(req.user.id);
      }
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students", error });
    }
  });

  app.get("/api/students/:id", requireAuth, requireRoles(['admin', 'coach', 'student']), async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const student = await storage.getStudent(id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      // Students can only access their own data, coaches can access their students
      if (req.user?.role === 'student' && student.id !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      if (req.user?.role === 'coach' && student.coachId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student", error });
    }
  });

  // Coach routes
  app.post("/api/coaches/register", async (req, res) => {
    try {
      const coachData = insertCoachSchema.parse(req.body);
      const existingCoach = await storage.getCoachByEmail(coachData.email);
      if (existingCoach) {
        return res.status(400).json({ message: "Coach with this email already exists" });
      }
      const coach = await storage.createCoach(coachData);
      res.status(201).json(coach);
    } catch (error) {
      res.status(400).json({ message: "Invalid coach data", error });
    }
  });

  app.get("/api/coaches", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const coaches = await storage.getAllCoaches();
      res.json(coaches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch coaches", error });
    }
  });

  app.get("/api/coaches/:id", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const coach = await storage.getCoach(id);
      if (!coach) {
        return res.status(404).json({ message: "Coach not found" });
      }
      
      // Coaches can only access their own data
      if (req.user?.role === 'coach' && coach.id !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(coach);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch coach", error });
    }
  });

  app.get("/api/coaches/:id/stats", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Coaches can only access their own stats
      if (req.user?.role === 'coach' && id !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const stats = await storage.getCoachStats(id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch coach stats", error });
    }
  });

  app.patch("/api/coaches/:id/status", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const coach = await storage.updateCoachStatus(id, status);
      if (!coach) {
        return res.status(404).json({ message: "Coach not found" });
      }
      res.json(coach);
    } catch (error) {
      res.status(500).json({ message: "Failed to update coach status", error });
    }
  });

  // Course routes
  app.get("/api/courses", async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch courses", error });
    }
  });

  app.post("/api/courses", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      res.status(400).json({ message: "Invalid course data", error });
    }
  });

  // Enrollment routes
  app.get("/api/enrollments", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      let enrollments;
      if (req.user?.role === 'admin') {
        // Admin gets all enrollments - we'll need to add this method
        enrollments = [];
      } else if (req.user?.role === 'coach') {
        enrollments = await storage.getEnrollmentsByCoachId(req.user.id);
      }
      res.json(enrollments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch enrollments", error });
    }
  });

  app.get("/api/students/:studentId/enrollments", requireAuth, requireRoles(['admin', 'coach', 'student']), async (req: AuthenticatedRequest, res) => {
    try {
      const studentId = parseInt(req.params.studentId);
      
      // Students can only access their own enrollments
      if (req.user?.role === 'student' && studentId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Coaches can only access their students' enrollments
      if (req.user?.role === 'coach') {
        const student = await storage.getStudent(studentId);
        if (!student || student.coachId !== req.user.id) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      const enrollments = await storage.getEnrollmentsByStudentId(studentId);
      res.json(enrollments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch enrollments", error });
    }
  });

  app.post("/api/enrollments", requireAuth, requireRoles(['admin', 'coach']), async (req, res) => {
    try {
      const enrollmentData = insertEnrollmentSchema.parse(req.body);
      const enrollment = await storage.createEnrollment(enrollmentData);
      res.status(201).json(enrollment);
    } catch (error) {
      res.status(400).json({ message: "Invalid enrollment data", error });
    }
  });

  app.patch("/api/enrollments/:id/progress", requireAuth, requireRoles(['admin', 'coach']), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { progress } = req.body;
      const enrollment = await storage.updateEnrollmentProgress(id, progress);
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      res.json(enrollment);
    } catch (error) {
      res.status(500).json({ message: "Failed to update enrollment progress", error });
    }
  });

  // Session routes (attendance tracking)
  app.get("/api/enrollments/:enrollmentId/sessions", requireAuth, requireRoles(['admin', 'coach', 'student']), async (req: AuthenticatedRequest, res) => {
    try {
      const enrollmentId = parseInt(req.params.enrollmentId);
      
      // Verify access to the enrollment
      const enrollment = await storage.getEnrollment(enrollmentId);
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      if (req.user?.role === 'student') {
        const student = await storage.getStudent(enrollment.studentId);
        if (!student || student.id !== req.user.id) {
          return res.status(403).json({ message: "Access denied" });
        }
      } else if (req.user?.role === 'coach' && enrollment.coachId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const sessions = await storage.getSessionsByEnrollmentId(enrollmentId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sessions", error });
    }
  });

  app.post("/api/sessions", requireAuth, requireRoles(['admin', 'coach']), async (req, res) => {
    try {
      const sessionData = insertSessionSchema.parse(req.body);
      const session = await storage.createSession(sessionData);
      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ message: "Invalid session data", error });
    }
  });

  app.get("/api/sessions", requireAuth, requireRoles(['admin', 'coach', 'student']), async (req: AuthenticatedRequest, res) => {
    try {
      let sessions: any[] = [];
      if (req.user?.role === 'admin') {
        sessions = await storage.getAllSessions();
      } else if (req.user?.role === 'coach') {
        const enrollments = await storage.getEnrollmentsByCoachId(req.user.id);
        const allSessions = await storage.getAllSessions();
        sessions = allSessions.filter((session: any) => 
          enrollments.some(enrollment => enrollment.id === session.enrollmentId)
        );
      } else if (req.user?.role === 'student') {
        const enrollments = await storage.getEnrollmentsByStudentId(req.user.id);
        const allSessions = await storage.getAllSessions();
        sessions = allSessions.filter((session: any) => 
          enrollments.some(enrollment => enrollment.id === session.enrollmentId)
        );
      }
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sessions", error });
    }
  });

  app.patch("/api/sessions/:id/status", requireAuth, requireRoles(['admin', 'coach']), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, actualDate } = req.body;
      const session = await storage.updateSessionStatus(id, status, actualDate ? new Date(actualDate) : undefined);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to update session status", error });
    }
  });

  app.patch("/api/sessions/:id/feedback", requireAuth, requireRoles(['admin', 'coach', 'student']), async (req: AuthenticatedRequest, res) => {
    try {
      const id = parseInt(req.params.id);
      const { coachFeedback, studentFeedback, rating } = req.body;
      
      // Students can only provide student feedback and rating
      if (req.user?.role === 'student') {
        const session = await storage.updateSessionFeedback(id, undefined, studentFeedback, rating);
        if (!session) {
          return res.status(404).json({ message: "Session not found" });
        }
        return res.json(session);
      }
      
      // Coaches and admins can provide coach feedback
      const session = await storage.updateSessionFeedback(id, coachFeedback, studentFeedback, rating);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to update session feedback", error });
    }
  });

  // Referral Link routes
  app.post("/api/referral-links", requireAuth, requireRole('coach'), async (req: AuthenticatedRequest, res) => {
    try {
      const linkData = { ...insertReferralLinkSchema.parse(req.body), coachId: req.user!.id };
      const link = await storage.createReferralLink(linkData);
      res.status(201).json(link);
    } catch (error) {
      res.status(400).json({ message: "Invalid link data", error });
    }
  });

  app.get("/api/referral-links/coach/:coachId", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      const coachId = parseInt(req.params.coachId);
      
      // Coaches can only access their own links
      if (req.user?.role === 'coach' && coachId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const links = await storage.getReferralLinksByCoachId(coachId);
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch referral links", error });
    }
  });

  app.get("/api/referral-links/:linkId", async (req, res) => {
    try {
      const linkId = req.params.linkId;
      const link = await storage.getReferralLinkByLinkId(linkId);
      if (!link) {
        return res.status(404).json({ message: "Referral link not found" });
      }
      const coach = await storage.getCoach(link.coachId);
      res.json({ link, coach });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch referral link", error });
    }
  });

  // Referral routes
  app.post("/api/referrals", async (req, res) => {
    try {
      const referralData = insertReferralSchema.parse(req.body);
      const referral = await storage.createReferral(referralData);
      
      // Mock HubSpot integration
      const hubspotResponse = await mockHubSpotIntegration(referral);
      
      res.status(201).json({ referral, hubspotResponse });
    } catch (error) {
      res.status(400).json({ message: "Invalid referral data", error });
    }
  });

  app.get("/api/referrals/coach/:coachId", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      const coachId = parseInt(req.params.coachId);
      
      // Coaches can only access their own referrals
      if (req.user?.role === 'coach' && coachId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const referrals = await storage.getReferralsByCoachId(coachId);
      res.json(referrals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch referrals", error });
    }
  });

  app.get("/api/referrals", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const referrals = await storage.getAllReferrals();
      res.json(referrals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch referrals", error });
    }
  });

  app.patch("/api/referrals/:id/status", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const referral = await storage.updateReferralStatus(id, status);
      if (!referral) {
        return res.status(404).json({ message: "Referral not found" });
      }
      res.json(referral);
    } catch (error) {
      res.status(500).json({ message: "Failed to update referral status", error });
    }
  });

  // Payout routes
  app.get("/api/payouts/coach/:coachId", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      const coachId = parseInt(req.params.coachId);
      
      // Coaches can only access their own payouts
      if (req.user?.role === 'coach' && coachId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const payouts = await storage.getPayoutsByCoachId(coachId);
      res.json(payouts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payouts", error });
    }
  });

  app.get("/api/payouts", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const payouts = await storage.getAllPayouts();
      res.json(payouts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payouts", error });
    }
  });

  app.post("/api/payouts", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const { coachId, amount } = req.body;
      const payout = await storage.createPayout(coachId, amount);
      res.status(201).json(payout);
    } catch (error) {
      res.status(400).json({ message: "Failed to create payout", error });
    }
  });

  // Attendance tracking routes
  app.get("/api/attendance/coach/:coachId", requireAuth, requireRoles(['admin', 'coach']), async (req: AuthenticatedRequest, res) => {
    try {
      const coachId = parseInt(req.params.coachId);
      
      // Coaches can only access their own attendance data
      if (req.user?.role === 'coach' && coachId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const attendanceRecords = await storage.getAttendanceByCoachId(coachId);
      res.json(attendanceRecords);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance records", error });
    }
  });

  app.post("/api/attendance", requireAuth, requireRoles(['admin', 'student']), async (req: AuthenticatedRequest, res) => {
    try {
      const attendanceData = req.body;
      const newRecord = await storage.createAttendanceRecord(attendanceData);
      res.status(201).json(newRecord);
    } catch (error) {
      res.status(500).json({ message: "Failed to create attendance record", error });
    }
  });

  // Referral link validation endpoint
  app.get("/api/referral-links/:linkId", async (req, res) => {
    try {
      const linkId = req.params.linkId;
      const link = await storage.getReferralLinkByLinkId(linkId);
      
      if (!link) {
        return res.status(404).json({ message: "Referral link not found" });
      }

      const coach = await storage.getCoach(link.coachId);
      res.json({
        link,
        coach: coach ? { name: coach.name, id: coach.id } : null
      });
    } catch (error) {
      console.error("Error validating referral link:", error);
      res.status(500).json({ message: "Failed to validate referral link" });
    }
  });

  // Student signup with referral tracking
  app.post("/api/auth/student/signup", async (req, res) => {
    try {
      const { 
        name, 
        email, 
        password, 
        phone, 
        dateOfBirth, 
        golfExperience, 
        referralCode,
        courseSelected,
        discountApplied 
      } = req.body;

      // Check if email already exists
      const existingStudent = await storage.getStudentByEmail(email);
      if (existingStudent) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Generate student ID
      const studentCount = await storage.getAllStudents();
      const studentId = `STU-${String(studentCount.length + 1).padStart(3, '0')}`;

      let referralLinkId = null;
      let coachId = null;

      // Process referral code if provided
      if (referralCode) {
        const referralLink = await storage.getReferralLinkByLinkId(referralCode);
        if (referralLink && referralLink.isActive) {
          referralLinkId = referralLink.id;
          coachId = referralLink.coachId;
        }
      }

      // Create student account
      const student = await storage.createStudent({
        studentId,
        name,
        email,
        password,
        phone,
        dateOfBirth: dateOfBirth || null,
        golfExperience,
        coachId,
        referralLinkId,
        referralSource: referralCode ? "coach" : "direct",
        discountApplied: discountApplied || 0
      });

      // Create referral record if this was a referral signup
      if (referralLinkId && coachId) {
        const originalPrice = 299;
        const finalPrice = originalPrice * (1 - (discountApplied || 0) / 100);
        const commissionRate = 0.15; // 15% commission
        const commissionAmount = finalPrice * commissionRate;

        await storage.createReferral({
          coachId,
          linkId: referralLinkId,
          studentId: student.id,
          studentName: name,
          studentEmail: email,
          courseSelected: courseSelected || 'red2blue-athlete',
          originalPrice: originalPrice.toString(),
          discountAmount: (originalPrice - finalPrice).toString(),
          finalPrice: finalPrice.toString(),
          commissionAmount: commissionAmount.toString(),
          status: 'active'
        });

        // Create enrollment for the course
        const course = await storage.getCourseByCode('red2blue-athlete');
        if (course) {
          await storage.createEnrollment({
            studentId: student.id,
            courseId: course.id,
            coachId,
            startDate: new Date().toISOString().split('T')[0],
            status: 'enrolled'
          });
        }
      }

      res.json({ 
        message: "Account created successfully", 
        student: { 
          id: student.id, 
          name: student.name, 
          email: student.email,
          referralApplied: !!referralCode
        } 
      });
    } catch (error) {
      console.error("Error creating student account:", error);
      res.status(500).json({ message: "Failed to create account" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Mock HubSpot integration
async function mockHubSpotIntegration(referral: any) {
  // Simulate API call to HubSpot
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        contactId: referral.hubspotContactId,
        status: "created",
        properties: {
          email: referral.studentEmail,
          firstname: referral.studentName.split(" ")[0],
          lastname: referral.studentName.split(" ")[1] || "",
          course_interest: referral.courseSelected,
          referral_source: "coach_referral",
          discount_applied: referral.discountAmount
        }
      });
    }, 1000);
  });
}
