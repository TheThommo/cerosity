import { storage } from "./storage";

export async function seedDatabase() {
  try {
    console.log("Seeding database with initial data...");

    // Create admin user
    const admin = await storage.createAdmin({
      email: "admin@red2blue.com",
      password: "admin123",
      name: "System Administrator",
    });
    console.log("Created admin user:", admin.email);

    // Create sample coaches
    const coach1 = await storage.createCoach({
      name: "John Anderson",
      email: "coach@red2blue.com",
      password: "coach123",
      certification: "PGA-UAE",
      phone: "+971-50-123-4567",
      bio: "Experienced golf instructor with 15+ years of coaching professionals and amateurs.",
      yearsExperience: 15,
      specializations: JSON.stringify(["Swing Analysis", "Short Game", "Mental Coaching"]),
    });
    console.log("Created coach:", coach1.name);

    const coach2 = await storage.createCoach({
      name: "Sarah Wilson",
      email: "sarah.wilson@red2blue.com", 
      password: "coach123",
      certification: "PGA-UK",
      phone: "+971-50-987-6543",
      bio: "Specialist in junior golf development and women's golf coaching.",
      yearsExperience: 8,
      specializations: JSON.stringify(["Junior Development", "Women's Golf", "Putting"]),
    });
    console.log("Created coach:", coach2.name);

    // Approve coaches
    await storage.updateCoachStatus(coach1.id, "approved");
    await storage.updateCoachStatus(coach2.id, "approved");

    // Create sample students
    const student1 = await storage.createStudent({
      name: "Michael Chen",
      email: "student@red2blue.com",
      password: "student123",
      phone: "+971-50-555-1234",
      dateOfBirth: "1995-03-15",
      golfExperience: "beginner",
      coachId: coach1.id,
    });
    console.log("Created student:", student1.name);

    const student2 = await storage.createStudent({
      name: "Emma Thompson",
      email: "emma.thompson@email.com",
      password: "student123",
      phone: "+971-50-555-5678",
      dateOfBirth: "1988-07-22",
      golfExperience: "intermediate",
      coachId: coach1.id,
    });
    console.log("Created student:", student2.name);

    const student3 = await storage.createStudent({
      name: "Ahmed Al-Rashid",
      email: "ahmed.rashid@email.com",
      password: "student123",
      phone: "+971-50-555-9012",
      dateOfBirth: "1992-11-08",
      golfExperience: "advanced",
      coachId: coach2.id,
    });
    console.log("Created student:", student3.name);

    // Create sample courses
    const course1 = await storage.createCourse({
      courseId: "BGF001",
      name: "Beginner Golf Fundamentals",
      description: "Perfect for newcomers to golf. Learn proper stance, grip, and basic swing mechanics.",
      duration: 8,
      sessionsPerWeek: 2,
      totalSessions: 16,
      price: "750.00",
      level: "beginner",
    });
    console.log("Created course:", course1.name);

    const course2 = await storage.createCourse({
      courseId: "ISI002",
      name: "Intermediate Swing Improvement",
      description: "Refine your technique and lower your handicap with advanced training methods.",
      duration: 10,
      sessionsPerWeek: 2,
      totalSessions: 20,
      price: "1000.00",
      level: "intermediate",
    });
    console.log("Created course:", course2.name);

    const course3 = await storage.createCourse({
      courseId: "ASG003",
      name: "Advanced Short Game Mastery",
      description: "Master your putting, chipping, and bunker play with professional techniques.",
      duration: 6,
      sessionsPerWeek: 3,
      totalSessions: 18,
      price: "1200.00",
      level: "advanced",
    });
    console.log("Created course:", course3.name);

    // Create sample enrollments
    const enrollment1 = await storage.createEnrollment({
      studentId: student1.id,
      courseId: course1.id,
      coachId: coach1.id,
      startDate: "2024-01-15",
      status: "in_progress",
    });
    console.log("Created enrollment for", student1.name);

    const enrollment2 = await storage.createEnrollment({
      studentId: student2.id,
      courseId: course2.id,
      coachId: coach1.id,
      startDate: "2024-02-01",
      status: "in_progress",
    });
    console.log("Created enrollment for", student2.name);

    const enrollment3 = await storage.createEnrollment({
      studentId: student3.id,
      courseId: course3.id,
      coachId: coach2.id,
      startDate: "2024-01-08",
      status: "completed",
      endDate: "2024-03-15",
      finalGrade: "A",
    });
    console.log("Created enrollment for", student3.name);

    // Update enrollment progress
    await storage.updateEnrollmentProgress(enrollment1.id, 45);
    await storage.updateEnrollmentProgress(enrollment2.id, 65);
    await storage.updateEnrollmentProgress(enrollment3.id, 100);

    // Create sample sessions
    const today = new Date();
    const sessions = [];

    // Sessions for enrollment1 (student1)
    for (let i = 1; i <= 8; i++) {
      const sessionDate = new Date(today);
      sessionDate.setDate(today.getDate() - (20 - i * 2));
      
      const session = await storage.createSession({
        enrollmentId: enrollment1.id,
        sessionNumber: i,
        scheduledDate: sessionDate,
        actualDate: i <= 6 ? sessionDate : null,
        status: i <= 6 ? "completed" : "scheduled",
        notes: i <= 6 ? `Session ${i} completed successfully` : null,
        skillsWorkedOn: i <= 6 ? JSON.stringify(["Basic stance", "Grip fundamentals", "Swing tempo"]) : null,
        coachFeedback: i <= 6 ? `Great progress in session ${i}. Student is improving steadily.` : null,
        studentFeedback: i <= 6 ? `Enjoyed the lesson. Coach explained everything clearly.` : null,
        rating: i <= 6 ? Math.floor(Math.random() * 2) + 4 : null, // 4-5 stars
      });
      sessions.push(session);
    }

    // Sessions for enrollment2 (student2)
    for (let i = 1; i <= 12; i++) {
      const sessionDate = new Date(today);
      sessionDate.setDate(today.getDate() - (30 - i * 2));
      
      const session = await storage.createSession({
        enrollmentId: enrollment2.id,
        sessionNumber: i,
        scheduledDate: sessionDate,
        actualDate: i <= 10 ? sessionDate : null,
        status: i <= 10 ? "completed" : "scheduled",
        notes: i <= 10 ? `Intermediate session ${i} completed` : null,
        skillsWorkedOn: i <= 10 ? JSON.stringify(["Swing analysis", "Course management", "Iron play"]) : null,
        coachFeedback: i <= 10 ? `Excellent technique development in session ${i}.` : null,
        studentFeedback: i <= 10 ? `Very helpful session. Seeing real improvement.` : null,
        rating: i <= 10 ? Math.floor(Math.random() * 2) + 4 : null,
      });
      sessions.push(session);
    }

    console.log(`Created ${sessions.length} sample sessions`);

    // Create referral links
    const referralLink1 = await storage.createReferralLink({
      coachId: coach1.id,
      campaignName: "Winter Golf Program 2024",
      courseId: course1.courseId,
      utmParams: "utm_source=social&utm_medium=facebook&utm_campaign=winter2024",
    });

    const referralLink2 = await storage.createReferralLink({
      coachId: coach2.id,
      campaignName: "Ladies Golf Special",
      courseId: course2.courseId,
      utmParams: "utm_source=email&utm_medium=newsletter&utm_campaign=ladies_special",
    });

    console.log("Created referral links");

    // Create sample referrals
    const referral1 = await storage.createReferral({
      coachId: coach1.id,
      linkId: referralLink1.id,
      studentId: student2.id,
      studentName: student2.name,
      studentEmail: student2.email,
      courseSelected: course2.courseId,
      originalPrice: "1000.00",
      discountAmount: "100.00",
      finalPrice: "900.00",
      status: "active",
    });

    console.log("Created sample referral");

    // Create sample payouts
    await storage.createPayout(coach1.id, 135); // 15% of $900
    await storage.createPayout(coach2.id, 180); // 15% of $1200

    console.log("Created sample payouts");
    console.log("Database seeding completed successfully!");

  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}