import {
  admins, students, coaches, courses, enrollments, sessions, referralLinks, referrals, payouts, attendanceRecords,
  type Admin, type InsertAdmin, type Student, type InsertStudent, type Coach, type InsertCoach,
  type Course, type InsertCourse, type Enrollment, type InsertEnrollment, type Session, type InsertSession,
  type ReferralLink, type InsertReferralLink, type Referral, type InsertReferral, type Payout,
  type AttendanceRecord, type InsertAttendanceRecord
} from "@shared/schema";
import { db } from "./db";
import { eq, count } from "drizzle-orm";
import { nanoid } from "nanoid";

export interface IStorage {
  // Admin operations
  getAdmin(id: number): Promise<Admin | undefined>;
  getAdminByEmail(email: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  
  // Student operations
  getStudent(id: number): Promise<Student | undefined>;
  getStudentByEmail(email: string): Promise<Student | undefined>;
  getStudentByStudentId(studentId: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  getAllStudents(): Promise<Student[]>;
  getStudentsByCoachId(coachId: number): Promise<Student[]>;

  // Coach operations
  getCoach(id: number): Promise<Coach | undefined>;
  getCoachByEmail(email: string): Promise<Coach | undefined>;
  getCoachByCoachId(coachId: string): Promise<Coach | undefined>;
  createCoach(coach: InsertCoach): Promise<Coach>;
  updateCoachStatus(id: number, status: string): Promise<Coach | undefined>;
  getAllCoaches(): Promise<Coach[]>;

  // Course operations
  getCourse(id: number): Promise<Course | undefined>;
  getCourseByCode(courseId: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  getAllCourses(): Promise<Course[]>;

  // Enrollment operations
  getEnrollment(id: number): Promise<Enrollment | undefined>;
  getEnrollmentsByStudentId(studentId: number): Promise<Enrollment[]>;
  getEnrollmentsByCoachId(coachId: number): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollmentProgress(id: number, progress: number): Promise<Enrollment | undefined>;
  updateEnrollmentStatus(id: number, status: string): Promise<Enrollment | undefined>;

  // Session operations
  getSession(id: number): Promise<Session | undefined>;
  getSessionsByEnrollmentId(enrollmentId: number): Promise<Session[]>;
  createSession(session: InsertSession): Promise<Session>;
  updateSessionStatus(id: number, status: string, actualDate?: Date): Promise<Session | undefined>;
  updateSessionFeedback(id: number, coachFeedback?: string, studentFeedback?: string, rating?: number): Promise<Session | undefined>;

  // Referral Link operations
  getReferralLink(id: number): Promise<ReferralLink | undefined>;
  getReferralLinkByLinkId(linkId: string): Promise<ReferralLink | undefined>;
  getReferralLinksByCoachId(coachId: number): Promise<ReferralLink[]>;
  createReferralLink(link: InsertReferralLink): Promise<ReferralLink>;

  // Referral operations
  getReferral(id: number): Promise<Referral | undefined>;
  getReferralsByCoachId(coachId: number): Promise<Referral[]>;
  getReferralsByLinkId(linkId: number): Promise<Referral[]>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  updateReferralStatus(id: number, status: string): Promise<Referral | undefined>;
  getAllReferrals(): Promise<Referral[]>;

  // Payout operations
  getPayoutsByCoachId(coachId: number): Promise<Payout[]>;
  createPayout(coachId: number, amount: number): Promise<Payout>;
  getAllPayouts(): Promise<Payout[]>;

  // Session operations
  getAllSessions(): Promise<Session[]>;

  // Enrollment operations
  getAllEnrollments(): Promise<Enrollment[]>;

  // Attendance operations
  getAttendanceByCoachId(coachId: number): Promise<AttendanceRecord[]>;
  createAttendanceRecord(attendance: InsertAttendanceRecord): Promise<AttendanceRecord>;

  // Analytics
  getCoachStats(coachId: number): Promise<{
    totalReferrals: number;
    activeStudents: number;
    pendingPayout: number;
    conversionRate: number;
  }>;
  
  getAdminStats(): Promise<{
    totalCoaches: number;
    totalStudents: number;
    totalEnrollments: number;
    completedCourses: number;
    totalRevenue: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // Admin operations
  async getAdmin(id: number): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.id, id));
    return admin;
  }

  async getAdminByEmail(email: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.email, email));
    return admin;
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const [admin] = await db
      .insert(admins)
      .values({
        ...insertAdmin,
        role: "admin",
      })
      .returning();
    return admin;
  }

  // Student operations
  async getStudent(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async getStudentByEmail(email: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.email, email));
    return student;
  }

  async getStudentByStudentId(studentId: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.studentId, studentId));
    return student;
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const studentCount = await db.select().from(students);
    const studentId = `STU-${String(studentCount.length + 1).padStart(3, '0')}`;
    
    const [student] = await db
      .insert(students)
      .values({
        ...insertStudent,
        studentId,
        phone: insertStudent.phone || null,
        dateOfBirth: insertStudent.dateOfBirth || null,
        golfExperience: insertStudent.golfExperience || null,
        coachId: insertStudent.coachId || null,
        referralLinkId: insertStudent.referralLinkId || null,
      })
      .returning();
    return student;
  }

  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(students);
  }

  async getStudentsByCoachId(coachId: number): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.coachId, coachId));
  }

  // Coach operations
  async getCoach(id: number): Promise<Coach | undefined> {
    const [coach] = await db.select().from(coaches).where(eq(coaches.id, id));
    return coach;
  }

  async getCoachByEmail(email: string): Promise<Coach | undefined> {
    const [coach] = await db.select().from(coaches).where(eq(coaches.email, email));
    return coach;
  }

  async getCoachByCoachId(coachId: string): Promise<Coach | undefined> {
    const [coach] = await db.select().from(coaches).where(eq(coaches.coachId, coachId));
    return coach;
  }

  async createCoach(insertCoach: InsertCoach): Promise<Coach> {
    const coachCount = await db.select().from(coaches);
    const coachId = `${insertCoach.certification}-${String(coachCount.length + 1).padStart(3, '0')}`;
    
    const [coach] = await db
      .insert(coaches)
      .values({
        ...insertCoach,
        coachId,
        phone: insertCoach.phone || null,
        bio: insertCoach.bio || null,
        yearsExperience: insertCoach.yearsExperience || null,
        specializations: insertCoach.specializations || null,
      })
      .returning();
    return coach;
  }

  async updateCoachStatus(id: number, status: string): Promise<Coach | undefined> {
    const [coach] = await db
      .update(coaches)
      .set({ status })
      .where(eq(coaches.id, id))
      .returning();
    return coach;
  }

  async getAllCoaches(): Promise<Coach[]> {
    return await db.select().from(coaches);
  }

  // Course operations
  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async getCourseByCode(courseId: string): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.courseId, courseId));
    return course;
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db
      .insert(courses)
      .values(insertCourse)
      .returning();
    return course;
  }

  async getAllCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  // Enrollment operations
  async getEnrollment(id: number): Promise<Enrollment | undefined> {
    const [enrollment] = await db.select().from(enrollments).where(eq(enrollments.id, id));
    return enrollment;
  }

  async getEnrollmentsByStudentId(studentId: number): Promise<Enrollment[]> {
    return await db.select().from(enrollments).where(eq(enrollments.studentId, studentId));
  }

  async getEnrollmentsByCoachId(coachId: number): Promise<Enrollment[]> {
    return await db.select().from(enrollments).where(eq(enrollments.coachId, coachId));
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const [enrollment] = await db
      .insert(enrollments)
      .values({
        ...insertEnrollment,
        endDate: insertEnrollment.endDate || null,
        finalGrade: insertEnrollment.finalGrade || null,
      })
      .returning();
    return enrollment;
  }

  async updateEnrollmentProgress(id: number, progress: number): Promise<Enrollment | undefined> {
    const [enrollment] = await db
      .update(enrollments)
      .set({ progress })
      .where(eq(enrollments.id, id))
      .returning();
    return enrollment;
  }

  async updateEnrollmentStatus(id: number, status: string): Promise<Enrollment | undefined> {
    const [enrollment] = await db
      .update(enrollments)
      .set({ status })
      .where(eq(enrollments.id, id))
      .returning();
    return enrollment;
  }

  // Session operations
  async getSession(id: number): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session;
  }

  async getSessionsByEnrollmentId(enrollmentId: number): Promise<Session[]> {
    return await db.select().from(sessions).where(eq(sessions.enrollmentId, enrollmentId));
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db
      .insert(sessions)
      .values({
        ...insertSession,
        actualDate: insertSession.actualDate || null,
        notes: insertSession.notes || null,
        skillsWorkedOn: insertSession.skillsWorkedOn || null,
        homework: insertSession.homework || null,
        coachFeedback: insertSession.coachFeedback || null,
        studentFeedback: insertSession.studentFeedback || null,
        rating: insertSession.rating || null,
      })
      .returning();
    return session;
  }

  async updateSessionStatus(id: number, status: string, actualDate?: Date): Promise<Session | undefined> {
    const updateData: any = { status };
    if (actualDate) {
      updateData.actualDate = actualDate;
    }
    
    const [session] = await db
      .update(sessions)
      .set(updateData)
      .where(eq(sessions.id, id))
      .returning();
    return session;
  }

  async updateSessionFeedback(id: number, coachFeedback?: string, studentFeedback?: string, rating?: number): Promise<Session | undefined> {
    const updateData: any = {};
    if (coachFeedback !== undefined) updateData.coachFeedback = coachFeedback;
    if (studentFeedback !== undefined) updateData.studentFeedback = studentFeedback;
    if (rating !== undefined) updateData.rating = rating;

    const [session] = await db
      .update(sessions)
      .set(updateData)
      .where(eq(sessions.id, id))
      .returning();
    return session;
  }

  // Referral Link operations
  async getReferralLink(id: number): Promise<ReferralLink | undefined> {
    const [link] = await db.select().from(referralLinks).where(eq(referralLinks.id, id));
    return link;
  }

  async getReferralLinkByLinkId(linkId: string): Promise<ReferralLink | undefined> {
    const [link] = await db.select().from(referralLinks).where(eq(referralLinks.linkId, linkId));
    return link;
  }

  async getReferralLinksByCoachId(coachId: number): Promise<ReferralLink[]> {
    return await db.select().from(referralLinks).where(eq(referralLinks.coachId, coachId));
  }

  async createReferralLink(insertLink: InsertReferralLink): Promise<ReferralLink> {
    const linkId = nanoid(8);
    const [link] = await db
      .insert(referralLinks)
      .values({
        ...insertLink,
        linkId,
        courseId: insertLink.courseId || null,
        utmParams: insertLink.utmParams || null,
      })
      .returning();
    return link;
  }

  // Referral operations
  async getReferral(id: number): Promise<Referral | undefined> {
    const [referral] = await db.select().from(referrals).where(eq(referrals.id, id));
    return referral;
  }

  async getReferralsByCoachId(coachId: number): Promise<Referral[]> {
    return await db.select().from(referrals).where(eq(referrals.coachId, coachId));
  }

  async getReferralsByLinkId(linkId: number): Promise<Referral[]> {
    return await db.select().from(referrals).where(eq(referrals.linkId, linkId));
  }

  async createReferral(insertReferral: InsertReferral): Promise<Referral> {
    const commissionAmount = parseFloat(insertReferral.finalPrice) * 0.15; // 15% commission
    const [referral] = await db
      .insert(referrals)
      .values({
        ...insertReferral,
        studentId: insertReferral.studentId || null,
        commissionAmount: commissionAmount.toString(),
        hubspotContactId: `hs_${nanoid(8)}`,
        status: insertReferral.status || "pending",
      })
      .returning();
    return referral;
  }

  async updateReferralStatus(id: number, status: string): Promise<Referral | undefined> {
    const [referral] = await db
      .update(referrals)
      .set({ status })
      .where(eq(referrals.id, id))
      .returning();
    return referral;
  }

  async getAllReferrals(): Promise<Referral[]> {
    return await db.select().from(referrals);
  }

  // Payout operations
  async getPayoutsByCoachId(coachId: number): Promise<Payout[]> {
    return await db.select().from(payouts).where(eq(payouts.coachId, coachId));
  }

  async createPayout(coachId: number, amount: number): Promise<Payout> {
    const [payout] = await db
      .insert(payouts)
      .values({
        coachId,
        amount: amount.toString(),
        status: "pending",
        processedAt: null,
      })
      .returning();
    return payout;
  }

  async getAllPayouts(): Promise<Payout[]> {
    return await db.select().from(payouts);
  }

  async getAllSessions(): Promise<Session[]> {
    return await db.select().from(sessions);
  }

  async getAllEnrollments(): Promise<Enrollment[]> {
    return await db.select().from(enrollments);
  }

  // Analytics
  async getCoachStats(coachId: number): Promise<{
    totalReferrals: number;
    activeStudents: number;
    pendingPayout: number;
    conversionRate: number;
  }> {
    const referrals = await this.getReferralsByCoachId(coachId);
    const activeReferrals = referrals.filter(r => r.status === "active");
    const payouts = await this.getPayoutsByCoachId(coachId);
    const pendingPayouts = payouts.filter(p => p.status === "pending");
    const pendingAmount = pendingPayouts.reduce((sum, p) => sum + parseFloat(p.amount), 0);

    return {
      totalReferrals: referrals.length,
      activeStudents: activeReferrals.length,
      pendingPayout: pendingAmount,
      conversionRate: referrals.length > 0 ? (activeReferrals.length / referrals.length) * 100 : 0,
    };
  }

  async getAdminStats(): Promise<{
    totalCoaches: number;
    totalStudents: number;
    totalEnrollments: number;
    completedCourses: number;
    totalRevenue: number;
  }> {
    const [coachCount] = await db.select({ count: count() }).from(coaches);
    const [studentCount] = await db.select({ count: count() }).from(students);
    const [enrollmentCount] = await db.select({ count: count() }).from(enrollments);
    
    const completedEnrollments = await db.select().from(enrollments).where(eq(enrollments.status, "completed"));
    const allReferrals = await db.select().from(referrals);
    const totalRevenue = allReferrals.reduce((sum, r) => sum + parseFloat(r.finalPrice), 0);

    return {
      totalCoaches: coachCount.count,
      totalStudents: studentCount.count,
      totalEnrollments: enrollmentCount.count,
      completedCourses: completedEnrollments.length,
      totalRevenue,
    };
  }

  // Attendance operations
  async getAttendanceByCoachId(coachId: number): Promise<AttendanceRecord[]> {
    const result = await db.select().from(attendanceRecords).where(eq(attendanceRecords.coachId, coachId));
    return result;
  }

  async createAttendanceRecord(insertAttendance: InsertAttendanceRecord): Promise<AttendanceRecord> {
    const [record] = await db
      .insert(attendanceRecords)
      .values(insertAttendance)
      .returning();
    return record;
  }
}

export const storage = new DatabaseStorage();
