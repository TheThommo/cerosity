import { pgTable, text, serial, integer, boolean, timestamp, decimal, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Admin users table
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("admin"), // admin, super_admin
  createdAt: timestamp("created_at").defaultNow(),
});

// Students table
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  studentId: text("student_id").notNull().unique(), // e.g., STU-001
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  phone: text("phone"),
  dateOfBirth: date("date_of_birth"),
  golfExperience: text("golf_experience"), // beginner, intermediate, advanced
  coachId: integer("coach_id").references(() => coaches.id),
  referralLinkId: integer("referral_link_id").references(() => referralLinks.id),
  referralSource: text("referral_source").default("direct"), // "coach", "red2blue_direct", "direct"
  discountApplied: integer("discount_applied").default(0), // percentage discount applied
  enrollmentDate: timestamp("enrollment_date").defaultNow(),
  status: text("status").notNull().default("active"), // active, inactive, completed
  createdAt: timestamp("created_at").defaultNow(),
});

export const coaches = pgTable("coaches", {
  id: serial("id").primaryKey(),
  coachId: text("coach_id").notNull().unique(), // e.g., PGA-UAE-001
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  certification: text("certification").notNull(), // EGF/UAE PGA
  phone: text("phone"),
  bio: text("bio"),
  yearsExperience: integer("years_experience"),
  specializations: text("specializations"), // JSON array as text
  status: text("status").notNull().default("pending"), // pending, approved, rejected, suspended
  createdAt: timestamp("created_at").defaultNow(),
});

// Course definitions
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  courseId: text("course_id").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  duration: integer("duration").notNull(), // in weeks
  sessionsPerWeek: integer("sessions_per_week").notNull(),
  totalSessions: integer("total_sessions").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  level: text("level").notNull(), // beginner, intermediate, advanced
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Student course enrollments
export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  coachId: integer("coach_id").references(() => coaches.id).notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  status: text("status").notNull().default("enrolled"), // enrolled, in_progress, completed, dropped
  progress: integer("progress").default(0), // percentage 0-100
  finalGrade: text("final_grade"), // A, B, C, D, F
  createdAt: timestamp("created_at").defaultNow(),
});

// Individual session attendance
export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  enrollmentId: integer("enrollment_id").references(() => enrollments.id).notNull(),
  sessionNumber: integer("session_number").notNull(),
  scheduledDate: timestamp("scheduled_date").notNull(),
  actualDate: timestamp("actual_date"),
  status: text("status").notNull().default("scheduled"), // scheduled, completed, missed, cancelled, rescheduled
  notes: text("notes"),
  skillsWorkedOn: text("skills_worked_on"), // JSON array as text
  homework: text("homework"),
  coachFeedback: text("coach_feedback"),
  studentFeedback: text("student_feedback"),
  rating: integer("rating"), // 1-5 stars
  createdAt: timestamp("created_at").defaultNow(),
});

export const referralLinks = pgTable("referral_links", {
  id: serial("id").primaryKey(),
  coachId: integer("coach_id").references(() => coaches.id).notNull(),
  linkId: text("link_id").notNull().unique(),
  campaignName: text("campaign_name").notNull(),
  courseId: text("course_id"),
  utmParams: text("utm_params"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  coachId: integer("coach_id").references(() => coaches.id).notNull(),
  linkId: integer("link_id").references(() => referralLinks.id).notNull(),
  studentId: integer("student_id").references(() => students.id),
  studentName: text("student_name").notNull(),
  studentEmail: text("student_email").notNull(),
  courseSelected: text("course_selected").notNull(),
  originalPrice: decimal("original_price", { precision: 10, scale: 2 }).notNull(),
  discountAmount: decimal("discount_amount", { precision: 10, scale: 2 }).notNull(),
  finalPrice: decimal("final_price", { precision: 10, scale: 2 }).notNull(),
  commissionAmount: decimal("commission_amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // pending, active, completed, cancelled
  hubspotContactId: text("hubspot_contact_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const payouts = pgTable("payouts", {
  id: serial("id").primaryKey(),
  coachId: integer("coach_id").references(() => coaches.id).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // pending, processed, failed
  paymentMethod: text("payment_method"),
  transactionId: text("transaction_id"),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const attendanceRecords = pgTable("attendance_records", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  coachId: integer("coach_id").references(() => coaches.id).notNull(),
  date: date("date").notNull(),
  status: text("status").notNull(), // present, absent, late
  notes: text("notes"),
  acknowledgedBy: text("acknowledged_by").notNull(), // student, admin
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertAdminSchema = createInsertSchema(admins).omit({
  id: true,
  role: true,
  createdAt: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  studentId: true,
  enrollmentDate: true,
  status: true,
  createdAt: true,
});

export const insertCoachSchema = createInsertSchema(coaches).omit({
  id: true,
  coachId: true,
  status: true,
  createdAt: true,
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  isActive: true,
  createdAt: true,
});

export const insertEnrollmentSchema = createInsertSchema(enrollments).omit({
  id: true,
  progress: true,
  createdAt: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export const insertReferralLinkSchema = createInsertSchema(referralLinks).omit({
  id: true,
  linkId: true,
  isActive: true,
  createdAt: true,
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  commissionAmount: true,
  hubspotContactId: true,
  createdAt: true,
});

// Types
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Coach = typeof coaches.$inferSelect;
export type InsertCoach = z.infer<typeof insertCoachSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Enrollment = typeof enrollments.$inferSelect;
export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type ReferralLink = typeof referralLinks.$inferSelect;
export type InsertReferralLink = z.infer<typeof insertReferralLinkSchema>;
export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Payout = typeof payouts.$inferSelect;
export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type InsertAttendanceRecord = typeof attendanceRecords.$inferInsert;
